from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from rest_framework_simplejwt.views import TokenObtainPairView,TokenRefreshView,TokenVerifyView

from ISETAG_COM_API import settings

urlpatterns = [
    path('admin/',               admin.site.urls),
    # path('api/token/',           TokenObtainPairView.as_view(), name='token_obtain_pair'),
    # path('api/token/refresh/',   TokenRefreshView.as_view(),    name='token_refresh'),
    # path('api/token/verify/',    TokenVerifyView.as_view(),     name='token_verify'),
    # path('authentification/',    include('authentification.urls')),
    path('user_api/',            include('user_api.urls')),
    path('campagne_api/',        include('campagne_api.urls')),
    path('prospect_api/',        include('prospect_api.urls')),
    path('specialite_api/',      include('specialite_api.urls')),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)