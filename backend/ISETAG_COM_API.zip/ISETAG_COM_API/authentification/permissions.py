from rest_framework.permissions import BasePermission

class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.profil.role == 'admin'

class IsSuperviseur(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.profil.role in ['admin', 'superviseur']

class IsAgent(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.profil.role in ['admin', 'superviseur', 'agent']