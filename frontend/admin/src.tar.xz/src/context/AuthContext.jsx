import React, { createContext, useState, useContext, useEffect } from 'react';
import { MOCK_USERS } from '../data/mockUsers';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Vérifier si un utilisateur est stocké dans localStorage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Erreur lors du chargement de l'utilisateur:", error);
        setUser(null);
      }
    }
    setIsLoading(false);
  }, []);

  /**
   * ⚠️ MOCK : vérifie email/mot de passe contre data/mockUsers.js, côté
   * client, sans appel réseau. À remplacer plus tard par un vrai appel
   * POST vers l'endpoint de login du backend (JWT), qui renverrait un
   * vrai token à stocker à la place du mot de passe en clair.
   *
   * Retourne { success: true } ou { success: false, error: 'code' }
   * pour que le composant Login affiche un message traduit adapté.
   */
  const login = async (email, password) => {
    // Simule un petit délai réseau pour que l'UI (spinner du bouton) ait
    // un sens, comme un vrai appel API le ferait.
    await new Promise((resolve) => setTimeout(resolve, 400));

    const found = MOCK_USERS.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
    );

    if (!found) {
      return { success: false, error: 'identifiantsInvalides' };
    }

    const { password: _omit, ...userData } = found;
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider value={{ user, isLoading, isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};