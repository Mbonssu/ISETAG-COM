// statsService.js
// Toute la logique de calcul des stats à partir des données brutes du CRUD.
// Aucun appel réseau ici : on ne fait que transformer des tableaux déjà récupérés.

const MONTHS_FR = [
  "Jan", "Fév", "Mar", "Avr", "Mai", "Jun",
  "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc",
];

// ---------- 1. KPI CARDS ----------
export function computeKPIs({ prospects, rendezVous, campagnes, sorties }) {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfPrevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

  const nouveauxCeMois = prospects.filter(
    (p) => new Date(p.createdAt) >= startOfMonth
  ).length;

  const nouveauxMoisPrecedent = prospects.filter((p) => {
    const d = new Date(p.createdAt);
    return d >= startOfPrevMonth && d < startOfMonth;
  }).length;

  const variation =
    nouveauxMoisPrecedent === 0
      ? 100
      : Math.round(
          ((nouveauxCeMois - nouveauxMoisPrecedent) / nouveauxMoisPrecedent) * 100
        );

  const campagnesActives = campagnes.filter(
    (c) => new Date(c.dateFin) >= now
  ).length;

  const rdvAVenir = rendezVous.filter(
    (r) => new Date(r.dateRendezVous) >= now
  ).length;

  return [
    { label: "Total prospects", value: prospects.length },
    { label: "Nouveaux ce mois", value: nouveauxCeMois, variation },
    { label: "Campagnes actives", value: campagnesActives },
    { label: "Sorties terrain", value: sorties.length },
    { label: "RDV à venir", value: rdvAVenir },
  ];
}

// ---------- 2. EVOLUTION CHART ----------
// Regroupe les prospects (via leur date de création) par mois, sur les N derniers mois
export function computeEvolution(prospects, monthsBack = 6) {
  const now = new Date();
  const buckets = [];

  for (let i = monthsBack - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      key: `${d.getFullYear()}-${d.getMonth()}`,
      label: `${MONTHS_FR[d.getMonth()]} ${d.getFullYear()}`,
      count: 0,
    });
  }

  prospects.forEach((p) => {
    const d = new Date(p.createdAt);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const bucket = buckets.find((b) => b.key === key);
    if (bucket) bucket.count += 1;
  });

  return buckets.map(({ label, count }) => ({ label, count }));
}

// ---------- 3. SOURCE DONUT ----------
// Regroupe les fiches de sortie par source (idSource / source_detail.libele)
export function computeSourceDistribution(fichesSortie) {
  const counts = {};

  fichesSortie.forEach((f) => {
    const libele = f.source_detail?.libele || f.idSource || "Inconnue";
    counts[libele] = (counts[libele] || 0) + 1;
  });

  const total = fichesSortie.length || 1;

  return Object.entries(counts)
    .map(([label, count]) => ({
      label,
      count,
      percentage: Math.round((count / total) * 100),
    }))
    .sort((a, b) => b.count - a.count);
}

// ---------- 4. FILIERE BARS ----------
// Regroupe les prospects par domaine d'étude
export function computeFiliereDistribution(prospects) {
  const counts = {};

  prospects.forEach((p) => {
    const filiere = p.domaineEtude || "Non renseigné";
    counts[filiere] = (counts[filiere] || 0) + 1;
  });

  return Object.entries(counts)
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
}

// ---------- 5. RECENT ACTIVITIES ----------
// Fusionne fiches de sortie, rendez-vous, suivis et relances en un seul flux
// chronologique, trié du plus récent au plus ancien.
export function computeRecentActivities(
  { fichesSortie, rendezVous, suivis, relances },
  limit = 10
) {
  const activities = [];

  fichesSortie.forEach((f) =>
    activities.push({
      type: "collecte",
      label: `Nouveau prospect collecté${
        f.prospect_detail?.nomComplet ? " : " + f.prospect_detail.nomComplet : ""
      }`,
      date: f.createdAt,
    })
  );

  rendezVous.forEach((r) =>
    activities.push({
      type: "rendezvous",
      label: `RDV programmé : ${r.sujet}`,
      date: r.createdAt,
    })
  );

  suivis.forEach((s) =>
    activities.push({
      type: "suivi",
      label: `Suivi ajouté : ${s.libeleSuivi}`,
      date: s.createdAt,
    })
  );

  relances.forEach((r) =>
    activities.push({
      type: "relance",
      label: `Relance : ${r.sujet}`,
      date: r.createdAt,
    })
  );

  return activities
    .filter((a) => a.date)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, limit);
}