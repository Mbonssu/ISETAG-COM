// useDashboardStats.js
// Un seul hook pour tout le dashboard : on appelle chaque route CRUD UNE FOIS
// (Promise.all), puis on calcule toutes les stats. Ça évite que chaque
// composant (KPICards, EvolutionChart, SourceDonut...) refasse les mêmes
// appels réseau en parallèle.

import { useEffect, useState } from "react";
import { api } from "./apiClient";
import {
  computeKPIs,
  computeEvolution,
  computeSourceDistribution,
  computeFiliereDistribution,
  computeRecentActivities,
} from "./statsService";

export function useDashboardStats() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    kpis: [],
    evolution: [],
    sourceDistribution: [],
    filiereDistribution: [],
    recentActivities: [],
    prospects: [], // utile direct pour ProspectsTable, pas besoin d'un 2e fetch
  });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setLoading(true);
        const [
          prospects,
          rendezVous,
          suivis,
          relances,
          campagnes,
          sorties,
          fichesSortie,
        ] = await Promise.all([
          api.getProspects(),
          api.getRendezVous(),
          api.getSuivis(),
          api.getRelances(),
          api.getCampagnes(),
          api.getSorties(),
          api.getFichesSortie(),
        ]);

        if (cancelled) return;

        setStats({
          prospects,
          kpis: computeKPIs({ prospects, rendezVous, campagnes, sorties }),
          evolution: computeEvolution(prospects, 6),
          sourceDistribution: computeSourceDistribution(fichesSortie),
          filiereDistribution: computeFiliereDistribution(prospects),
          recentActivities: computeRecentActivities(
            { fichesSortie, rendezVous, suivis, relances },
            10
          ),
        });
      } catch (err) {
        if (!cancelled) setError(err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { ...stats, loading, error };
}