import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, FileText, User, Calendar, Star, Tag, MapPin, Loader, AlertCircle } from 'lucide-react';
import { ficheService } from '../../services/ficheService';
import { sortieService } from '../../services/sortieService';
import '../Prospects/Prospects.css';

// ⚠️ LECTURE SEULE : cette fiche a été créée par un agent sur le terrain
// via l'app mobile. Pas de bouton "Modifier" ici — l'admin web ne fait
// que consulter les fiches déjà remontées.

const FichesDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [fiche, setFiche] = useState(null);
  const [etablissementNom, setEtablissementNom] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchFiche = async () => {
      setLoading(true);
      setError(null);
      try {
        const raw = await ficheService.getById(id);
        console.log('📥 Fiche chargée:', raw);
        const data = Array.isArray(raw) ? raw[0] : raw;
        setFiche(data);

        // L'établissement n'est pas directement sur la fiche : il faut
        // remonter via participation_detail.idSortie -> sortie.etablissement_detail
        const idSortie = data?.participation_detail?.idSortie;
        if (idSortie) {
          try {
            const sortieRaw = await sortieService.getById(idSortie);
            const sortie = Array.isArray(sortieRaw) ? sortieRaw[0] : sortieRaw;
            setEtablissementNom(sortie?.etablissement_detail?.nom || null);
          } catch {
            // pas grave, on affiche juste sans le nom de l'établissement
          }
        }
      } catch (err) {
        console.error('❌ Erreur de chargement:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchFiche();
  }, [id]);

  if (loading) {
    return <div className="page-container"><div className="loading-container"><Loader size={48} className="spin" /><p>Chargement de la fiche...</p></div></div>;
  }
  if (error || !fiche) {
    return (
      <div className="page-container">
        <div className="error-container">
          <AlertCircle size={48} color="#ef4444" />
          <h3>Erreur de chargement</h3>
          <p>{error || 'Fiche introuvable'}</p>
          <button className="btn-outline" onClick={() => navigate('/fiches')}>Retour à la liste</button>
        </div>
      </div>
    );
  }

  const nomProspect = fiche.prospect_detail?.nomComplet || fiche.idProspect;
  const nomSource = fiche.source_detail?.libele || fiche.idSource;

  return (
    <div className="page-container">
      <div className="page-header-actions">
        <div>
          <h1 className="page-title-h1">Détail de la fiche de collecte</h1>
          <p className="page-description">Fiche remontée depuis le terrain — consultation uniquement.</p>
        </div>
        <button className="btn-outline" onClick={() => navigate('/fiches')}>
          <ArrowLeft size={18} /> Retour
        </button>
      </div>

      <div className="detail-grid">
        <div className="detail-card">
          <div className="detail-header">
            <div className="detail-avatar" style={{ background: 'linear-gradient(135deg, #1a5c2a, #2d7a3a)', color: 'white' }}>
              <FileText size={24} />
            </div>
            <div>
              <h2>{nomProspect}</h2>
              <span className="code-badge">{fiche.idFiche}</span>
            </div>
          </div>
          <div className="detail-info">
            <div className="info-row">
              <User size={18} />
              <span>
                Prospect: <strong>{nomProspect}</strong>
                {fiche.idProspect && (
                  <button
                    className="btn-outline"
                    style={{ marginLeft: 10, padding: '2px 10px', fontSize: 12 }}
                    onClick={() => navigate(`/prospects/${fiche.idProspect}`)}
                  >
                    Voir la fiche prospect
                  </button>
                )}
              </span>
            </div>
            <div className="info-row"><Tag size={18} /><span>Source: {nomSource}</span></div>
            {etablissementNom && (
              <div className="info-row"><MapPin size={18} /><span>Établissement: {etablissementNom}</span></div>
            )}
            <div className="info-row"><Calendar size={18} /><span>Date de collecte: {fiche.dateCollecte ? new Date(fiche.dateCollecte).toLocaleString('fr-FR') : '-'}</span></div>
            <div className="info-row">
              <Star size={18} />
              <span>Score d'intérêt: <strong>{fiche.scoreInteret ?? '-'}</strong></span>
            </div>
          </div>
        </div>

        <div className="detail-card full-width">
          <h3>Commentaire de l'agent</h3>
          <p className="detail-notes">{fiche.commentaire || 'Aucun commentaire'}</p>
        </div>
      </div>
    </div>
  );
};

export default FichesDetail;