import 'package:flutter/material.dart';
import '../models/prospect_model.dart';
import '../services/database_service.dart';

class AuthProvider with ChangeNotifier {
  User? _currentUser;
  bool _isAuthenticated = false;
  final DatabaseService _dbService = DatabaseService();

  User? get currentUser => _currentUser;
  bool get isAuthenticated => _isAuthenticated;

  Future<bool> login(String email, String password) async {
    // For demo purposes, if user doesn't exist, create a default one
    User? user = await _dbService.getUserByEmail(email);
    
    if (user == null && email == "admin@isetag.com" && password == "admin123") {
      user = User(
        email: email,
        nom: "Morreaux",
        prenom: "Jean",
        role: "admin",
        password: password,
      );
      await _dbService.saveUser(user);
    }

    if (user != null && user.password == password) {
      _currentUser = user;
      _isAuthenticated = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _currentUser = null;
    _isAuthenticated = false;
    notifyListeners();
  }

  Future<bool> recoverPassword(String email) async {
    // Simulated recovery logic
    return true;
  }
}
