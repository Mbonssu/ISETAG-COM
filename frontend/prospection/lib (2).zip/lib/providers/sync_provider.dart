import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../../services/database_service.dart';
import '../models/prospect_model.dart';

class SyncProvider with ChangeNotifier {
  bool _isSyncing = false;
  double _syncProgress = 0.0;
  bool _isOnline = true;
  final DatabaseService _dbService = DatabaseService();

  bool get isSyncing => _isSyncing;
  double get syncProgress => _syncProgress;
  bool get isOnline => _isOnline;

  SyncProvider() {
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      _isOnline = result != ConnectivityResult.none;
      if (_isOnline) {
        syncData();
      }
      notifyListeners();
    } as void Function(List<ConnectivityResult> event)?);
  }

  Future<void> syncData() async {
    if (_isSyncing || !_isOnline) return;

    _isSyncing = true;
    _syncProgress = 0.0;
    notifyListeners();

    try {
      final unsynced = await _dbService.getUnsyncedProspects();
      if (unsynced.isEmpty) {
        _syncProgress = 1.0;
      } else {
        for (int i = 0; i < unsynced.length; i++) {
          // Simulated network delay and API call
          await Future.delayed(const Duration(milliseconds: 500));
          
          final prospect = unsynced[i];
          // Here you would call your remote API: await api.uploadProspect(prospect);
          
          await _dbService.isar.writeTxn(() async {
            prospect.isSynced = true;
            await _dbService.isar.prospects.put(prospect);
          });
          
          _syncProgress = (i + 1) / unsynced.length;
          notifyListeners();
        }
      }
    } catch (e) {
      debugPrint('Sync error: $e');
    } finally {
      _isSyncing = false;
      notifyListeners();
    }
  }
}
