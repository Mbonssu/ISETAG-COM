import 'package:isar/isar.dart';

part 'prospect_model.g.dart';

@collection
class Prospect {
  Id id = Isar.autoIncrement;

  @Index()
  late String nomComplet;
  
  late String telephone;
  late String telephoneParent;
  late String email;
  late String ville;
  late String ecoleOrigine;
  late String filiereInteressee;
  late String concerne; // parent, enfant
  late String commentaire;
  
  @Index()
  late DateTime dateRelance;
  
  @Index()
  late String statut; // nouveau, contacté, à relancer
  
  late DateTime createdAt;
  late DateTime updatedAt;
  
  bool isSynced = false;

  Prospect({
    required this.nomComplet,
    required this.telephone,
    required this.telephoneParent,
    required this.email,
    required this.ville,
    required this.ecoleOrigine,
    required this.filiereInteressee,
    required this.concerne,
    required this.commentaire,
    required this.dateRelance,
    required this.statut,
    required this.createdAt,
    required this.updatedAt,
    this.isSynced = false,
  });
}

@collection
class User {
  Id id = Isar.autoIncrement;
  
  @Index(unique: true)
  late String email;
  
  late String nom;
  late String prenom;
  late String role; // prospecteur, admin
  late String password;
  
  User({
    required this.email,
    required this.nom,
    required this.prenom,
    required this.role,
    required this.password,
  });
}

@collection
class Etablissement {
  Id id = Isar.autoIncrement;
  late String nomEtablissement;
  late String ville;
  late String adresse;
  
  Etablissement({
    required this.nomEtablissement,
    required this.ville,
    required this.adresse,
  });
}

@collection
class Specialite {
  Id id = Isar.autoIncrement;
  late String libelleSpecialite;
  
  Specialite({
    required this.libelleSpecialite,
  });
}
