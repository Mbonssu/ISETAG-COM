import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/sync_provider.dart';
import '../theme/app_theme.dart';

class SyncPage extends StatelessWidget {
  const SyncPage({super.key});

  @override
  Widget build(BuildContext context) {
    final syncProvider = Provider.of<SyncProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Synchronisation')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              syncProvider.isOnline ? Icons.cloud_done : Icons.cloud_off,
              size: 80,
              color: syncProvider.isOnline ? AppColors.successGreen : AppColors.errorRed,
            ),
            const SizedBox(height: 24),
            Text(
              syncProvider.isOnline ? 'Connecté au serveur' : 'Mode hors ligne',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              syncProvider.isOnline 
                ? 'Vos données sont en cours de synchronisation.' 
                : 'Vos données sont stockées localement et seront synchronisées dès le retour du réseau.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 48),
            if (syncProvider.isSyncing) ...[
              LinearProgressIndicator(
                value: syncProvider.syncProgress,
                backgroundColor: Colors.grey[200],
                color: AppColors.primaryGreen,
              ),
              const SizedBox(height: 16),
              Text('${(syncProvider.syncProgress * 100).toInt()}% synchronisé'),
            ] else if (syncProvider.isOnline) ...[
              ElevatedButton.icon(
                onPressed: () => syncProvider.syncData(),
                icon: const Icon(Icons.sync),
                label: const Text('SYNCHRONISER MAINTENANT'),
              ),
            ],
            const SizedBox(height: 32),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text('Statistiques de synchronisation', style: TextStyle(fontWeight: FontWeight.bold)),
                    const Divider(),
                    _buildStatRow('Dernière synchro', 'Il y a 5 min'),
                    _buildStatRow('Éléments en attente', '0'),
                    _buildStatRow('Statut du serveur', 'Opérationnel'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
