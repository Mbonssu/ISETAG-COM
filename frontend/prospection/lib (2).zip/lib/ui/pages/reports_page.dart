import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../services/database_service.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  final _dbService = DatabaseService();
  int _totalProspects = 0;
  Map<String, int> _byStatus = {};

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final prospects = await _dbService.getAllProspects();
    setState(() {
      _totalProspects = prospects.length;
      _byStatus = {
        'Nouveau': prospects.where((p) => p.statut == 'nouveau').length,
        'Contacté': prospects.where((p) => p.statut == 'contacté').length,
        'Relance': prospects.where((p) => p.statut == 'à relancer').length,
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rapports & Statistiques')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Aperçu global', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            _buildStatCard('Total Prospects', _totalProspects.toString(), Icons.people, Colors.blue),
            const SizedBox(height: 24),
            Text('Répartition par statut', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: PieChart(
                PieChartData(
                  sections: _byStatus.entries.map((e) {
                    final color = e.key == 'Nouveau' ? Colors.blue : (e.key == 'Contacté' ? Colors.green : Colors.orange);
                    return PieChartSectionData(
                      color: color,
                      value: e.value.toDouble(),
                      title: '${e.value}',
                      radius: 50,
                      titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Text('Actions d\'exportation', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildExportButton(
                    'Export CSV',
                    Icons.table_chart,
                    Colors.green,
                    () => _exportData('csv'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildExportButton(
                    'Export PDF',
                    Icons.picture_as_pdf,
                    Colors.red,
                    () => _exportData('pdf'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: color, size: 40),
        title: Text(label),
        trailing: Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildExportButton(String label, IconData icon, Color color, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Text(label),
      style: ElevatedButton.styleFrom(backgroundColor: color),
    );
  }

  void _exportData(String format) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Exportation $format en cours...')),
    );
    // Implementation would use 'csv' or 'pdf' packages to generate and share files
  }
}
