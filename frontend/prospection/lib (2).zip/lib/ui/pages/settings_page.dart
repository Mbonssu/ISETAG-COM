import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import 'login_page.dart';
import 'sync_page.dart';
import 'reports_page.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String _selectedLanguage = 'Français';

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: ListView(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            color: AppColors.primaryGreen.withOpacity(0.05),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 40,
                  backgroundColor: AppColors.primaryGreen,
                  child: Icon(Icons.person, size: 40, color: Colors.white),
                ),
                const SizedBox(width: 20),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${user?.prenom} ${user?.nom}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    Text(user?.email ?? '', style: const TextStyle(color: Colors.grey)),
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(color: AppColors.secondaryYellow, borderRadius: BorderRadius.circular(4)),
                      child: Text(user?.role.toUpperCase() ?? '', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildSectionTitle('Application'),
          _buildSettingTile(
            Icons.language, 
            'Langue', 
            _selectedLanguage, 
            () => _showLanguageDialog(),
          ),
          _buildSettingTile(
            Icons.sync, 
            'Synchronisation', 
            'Gérer le transfert de données', 
            () => Navigator.push(context, MaterialPageRoute(builder: (context) => const SyncPage())),
          ),
          _buildSettingTile(
            Icons.bar_chart, 
            'Rapports', 
            'Voir les statistiques', 
            () => Navigator.push(context, MaterialPageRoute(builder: (context) => const ReportsPage())),
          ),
          const SizedBox(height: 16),
          _buildSectionTitle('Compte'),
          _buildSettingTile(Icons.lock_outline, 'Changer le mot de passe', '', () {}),
          _buildSettingTile(
            Icons.logout, 
            'Déconnexion', 
            '', 
            () {
              auth.logout();
              Navigator.of(context, rootNavigator: true).pushReplacement(
                MaterialPageRoute(builder: (context) => const LoginPage()),
              );
            },
            textColor: AppColors.errorRed,
          ),
          const SizedBox(height: 32),
          const Center(child: Text('Version 1.0.0', style: TextStyle(color: Colors.grey, fontSize: 12))),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
      child: Text(title, style: const TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildSettingTile(IconData icon, String title, String subtitle, VoidCallback onTap, {Color? textColor}) {
    return ListTile(
      leading: Icon(icon, color: textColor ?? AppColors.textDark),
      title: Text(title, style: TextStyle(color: textColor ?? AppColors.textDark, fontWeight: FontWeight.w500)),
      subtitle: subtitle.isNotEmpty ? Text(subtitle) : null,
      trailing: const Icon(Icons.chevron_right, size: 20),
      onTap: onTap,
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Choisir la langue'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Français'),
              leading: Radio<String>(
                value: 'Français',
                groupValue: _selectedLanguage,
                onChanged: (v) {
                  setState(() => _selectedLanguage = v!);
                  Navigator.pop(context);
                },
              ),
            ),
            ListTile(
              title: const Text('English'),
              leading: Radio<String>(
                value: 'English',
                groupValue: _selectedLanguage,
                onChanged: (v) {
                  setState(() => _selectedLanguage = v!);
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
