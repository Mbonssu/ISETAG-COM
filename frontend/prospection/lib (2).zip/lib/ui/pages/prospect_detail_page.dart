import 'package:flutter/material.dart';
import '../../models/prospect_model.dart';
import '../../services/database_service.dart';
import '../theme/app_theme.dart';

class ProspectDetailPage extends StatelessWidget {
  final Prospect prospect;
  const ProspectDetailPage({super.key, required this.prospect});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Détails du prospect')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 50,
                    backgroundColor: AppColors.primaryGreen,
                    child: Icon(Icons.person, size: 50, color: Colors.white),
                  ),
                  const SizedBox(height: 16),
                  Text(prospect.nomComplet, style: Theme.of(context).textTheme.titleLarge),
                  Text(prospect.statut.toUpperCase(), style: const TextStyle(color: AppColors.secondaryYellow, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 32),
            _buildInfoRow(Icons.phone, 'Téléphone', prospect.telephone),
            _buildInfoRow(Icons.contact_phone, 'Parent', prospect.telephoneParent),
            _buildInfoRow(Icons.email, 'Email', prospect.email),
            _buildInfoRow(Icons.location_city, 'Ville', prospect.ville),
            _buildInfoRow(Icons.school, 'École', prospect.ecoleOrigine),
            _buildInfoRow(Icons.category, 'Filière', prospect.filiereInteressee),
            _buildInfoRow(Icons.person_outline, 'Concerné', prospect.concerne),
            _buildInfoRow(Icons.calendar_today, 'Date de relance', '${prospect.dateRelance.day}/${prospect.dateRelance.month}/${prospect.dateRelance.year}'),
            _buildInfoRow(Icons.comment, 'Commentaire', prospect.commentaire),
            
            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _showRelanceDialog(context),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                    child: const Text('RELANCER'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _updateStatus(context, 'contacté'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.successGreen),
                    child: const Text('CONTACTÉ'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primaryGreen, size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
            ],
          ),
        ],
      ),
    );
  }

  void _updateStatus(BuildContext context, String status) async {
    final db = DatabaseService();
    await db.updateProspectStatus(prospect.id, status, prospect.dateRelance);
    if (context.mounted) Navigator.pop(context);
  }

  void _showRelanceDialog(BuildContext context) async {
    DateTime selectedDate = DateTime.now().add(const Duration(days: 7));
    
    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Planifier une relance'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Choisissez la nouvelle date de relance :'),
              const SizedBox(height: 16),
              ListTile(
                title: Text('${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: selectedDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (date != null) setState(() => selectedDate = date);
                },
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('ANNULER')),
            ElevatedButton(
              onPressed: () async {
                final db = DatabaseService();
                await db.updateProspectStatus(prospect.id, 'à relancer', selectedDate);
                if (context.mounted) {
                  Navigator.pop(context);
                  Navigator.pop(context);
                }
              },
              child: const Text('CONFIRMER'),
            ),
          ],
        ),
      ),
    );
  }
}
