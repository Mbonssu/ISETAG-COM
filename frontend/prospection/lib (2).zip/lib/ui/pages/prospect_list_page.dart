import 'package:flutter/material.dart';
import '../../models/prospect_model.dart';
import '../../services/database_service.dart';
import '../theme/app_theme.dart';
import 'prospect_detail_page.dart';

class ProspectListPage extends StatefulWidget {
  final bool onlyRelances;
  const ProspectListPage({super.key, this.onlyRelances = false});

  @override
  State<ProspectListPage> createState() => _ProspectListPageState();
}

class _ProspectListPageState extends State<ProspectListPage> {
  final _dbService = DatabaseService();
  List<Prospect> _prospects = [];
  String _searchQuery = '';
  String _statusFilter = 'tous';

  @override
  void initState() {
    super.initState();
    _loadProspects();
  }

  Future<void> _loadProspects() async {
    final all = await _dbService.getAllProspects();
    setState(() {
      _prospects = all.where((p) {
        if (widget.onlyRelances && p.statut != 'à relancer') return false;
        if (_statusFilter != 'tous' && p.statut != _statusFilter) return false;
        if (_searchQuery.isNotEmpty && !p.nomComplet.toLowerCase().contains(_searchQuery.toLowerCase())) return false;
        return true;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.onlyRelances ? 'Relances' : 'Liste des prospects'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (v) {
                      _searchQuery = v;
                      _loadProspects();
                    },
                    decoration: InputDecoration(
                      hintText: 'Rechercher...',
                      fillColor: Colors.white,
                      filled: true,
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.filter_list, color: Colors.white),
                  onSelected: (v) {
                    _statusFilter = v;
                    _loadProspects();
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(value: 'tous', child: Text('Tous')),
                    const PopupMenuItem(value: 'nouveau', child: Text('Nouveau')),
                    const PopupMenuItem(value: 'contacté', child: Text('Contacté')),
                    const PopupMenuItem(value: 'à relancer', child: Text('À relancer')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      body: _prospects.isEmpty
          ? const Center(child: Text('Aucun prospect trouvé'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _prospects.length,
              itemBuilder: (context, i) {
                final p = _prospects[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primaryGreen,
                      child: Text(p.nomComplet[0].toUpperCase(), style: const TextStyle(color: Colors.white)),
                    ),
                    title: Text(p.nomComplet, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${p.ville} - ${p.statut}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ProspectDetailPage(prospect: p)),
                    ).then((_) => _loadProspects()),
                  ),
                );
              },
            ),
    );
  }
}
