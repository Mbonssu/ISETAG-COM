import 'package:flutter/material.dart';
import '../../models/prospect_model.dart';
import '../../services/database_service.dart';

class ProspectFormPage extends StatefulWidget {
  const ProspectFormPage({super.key});

  @override
  State<ProspectFormPage> createState() => _ProspectFormPageState();
}

class _ProspectFormPageState extends State<ProspectFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _dbService = DatabaseService();
  
  final _nomController = TextEditingController();
  final _telController = TextEditingController();
  final _telParentController = TextEditingController();
  final _emailController = TextEditingController();
  final _villeController = TextEditingController();
  final _ecoleController = TextEditingController();
  final _filiereController = TextEditingController();
  final _commentaireController = TextEditingController();
  
  String _concerne = 'enfant';
  DateTime _dateRelance = DateTime.now().add(const Duration(days: 7));

  Future<void> _saveProspect() async {
    if (_formKey.currentState!.validate()) {
      final prospect = Prospect(
        nomComplet: _nomController.text,
        telephone: _telController.text,
        telephoneParent: _telParentController.text,
        email: _emailController.text,
        ville: _villeController.text,
        ecoleOrigine: _ecoleController.text,
        filiereInteressee: _filiereController.text,
        concerne: _concerne,
        commentaire: _commentaireController.text,
        dateRelance: _dateRelance,
        statut: 'nouveau',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      
      await _dbService.saveProspect(prospect);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Prospect ajouté avec succès')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajouter un prospect')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTextField(_nomController, 'Nom complet', Icons.person),
              _buildTextField(_telController, 'Téléphone', Icons.phone),
              _buildTextField(_telParentController, 'Téléphone du parent', Icons.contact_phone),
              _buildTextField(_emailController, 'Email', Icons.email),
              _buildTextField(_villeController, 'Ville', Icons.location_city),
              _buildTextField(_ecoleController, 'École d\'origine', Icons.school),
              _buildTextField(_filiereController, 'Filière intéressée', Icons.category),
              
              const SizedBox(height: 16),
              const Text('Concerné :', style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  Radio<String>(
                    value: 'parent',
                    groupValue: _concerne,
                    onChanged: (v) => setState(() => _concerne = v!),
                  ),
                  const Text('Parent'),
                  Radio<String>(
                    value: 'enfant',
                    groupValue: _concerne,
                    onChanged: (v) => setState(() => _concerne = v!),
                  ),
                  const Text('Enfant'),
                ],
              ),
              
              _buildTextField(_commentaireController, 'Commentaire', Icons.comment, maxLines: 3),
              
              const SizedBox(height: 16),
              ListTile(
                title: const Text('Date de relance proposée'),
                subtitle: Text('${_dateRelance.day}/${_dateRelance.month}/${_dateRelance.year}'),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: _dateRelance,
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (date != null) setState(() => _dateRelance = date);
                },
              ),
              
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _saveProspect,
                child: const Text('ENREGISTRER'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
        validator: (v) => v == null || v.isEmpty ? 'Champ requis' : null,
      ),
    );
  }
}
