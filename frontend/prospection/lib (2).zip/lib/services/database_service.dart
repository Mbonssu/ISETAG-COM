import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../models/prospect_model.dart';

class DatabaseService {
  late Isar isar;

  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    isar = await Isar.open(
      [ProspectSchema, UserSchema, EtablissementSchema, SpecialiteSchema],
      directory: dir.path,
    );
  }

  // Prospect Operations
  Future<void> saveProspect(Prospect prospect) async {
    await isar.writeTxn(() async {
      await isar.prospects.put(prospect);
    });
  }

  Future<List<Prospect>> getAllProspects() async {
    return await isar.prospects.where().findAll();
  }

  Future<List<Prospect>> getUnsyncedProspects() async {
    return await isar.prospects.filter().isSyncedEqualTo(false).findAll();
  }

  Future<void> updateProspectStatus(int id, String status, DateTime nextRelance) async {
    await isar.writeTxn(() async {
      final prospect = await isar.prospects.get(id);
      if (prospect != null) {
        prospect.statut = status;
        prospect.dateRelance = nextRelance;
        prospect.updatedAt = DateTime.now();
        prospect.isSynced = false;
        await isar.prospects.put(prospect);
      }
    });
  }

  // User Operations
  Future<User?> getUserByEmail(String email) async {
    return await isar.users.filter().emailEqualTo(email).findFirst();
  }

  Future<void> saveUser(User user) async {
    await isar.writeTxn(() async {
      await isar.users.put(user);
    });
  }
}
