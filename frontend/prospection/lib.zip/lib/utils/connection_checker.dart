// // // lib/utils/connection_checker.dart
// // import 'dart:async';
// // import 'package:connectivity_plus/connectivity_plus.dart';
// // // import 'package:http/http.dart' as http;
// // import 'package:isetagcom/services/api_service.dart';

// // class ConnectionChecker {
// //   static final ConnectionChecker _instance = ConnectionChecker._internal();
// //   factory ConnectionChecker() => _instance;
// //   ConnectionChecker._internal();

// //   final Connectivity _connectivity = Connectivity();
// //   final ApiService _api = ApiService();
  
// //   bool _hasConnection = false;
// //   bool _isApiReachable = false;
  
// //   // Stream for connection status changes
// //   final _connectionController = StreamController<bool>.broadcast();
// //   Stream<bool> get connectionStream => _connectionController.stream;
  
// //   // Stream for API reachability changes
// //   final _apiReachableController = StreamController<bool>.broadcast();
// //   Stream<bool> get apiReachableStream => _apiReachableController.stream;

// //   // Getters
// //   bool get hasConnection => _hasConnection;
// //   bool get isApiReachable => _isApiReachable;
// //   bool get isConnected => _hasConnection && _isApiReachable;

// //   // Initialize the checker
// //   Future<void> init() async {
// //     // Check initial connection
// //     await _checkConnection();
    
// //     // Listen to connectivity changes
// //     _connectivity.onConnectivityChanged.listen((results) {
// //       _checkConnection();
// //     });
// //   }

// //   // Check connection status
// //   Future<void> _checkConnection() async {
// //     try {
// //       final results = await _connectivity.checkConnectivity();
// //       final bool wasConnected = _hasConnection;
// //       final bool wasApiReachable = _isApiReachable;
      
// //       // Check if any connection exists
// //       _hasConnection = results.any((r) => r != ConnectivityResult.none);
      
// //       // If we have connection, check API
// //       if (_hasConnection) {
// //         _isApiReachable = await _checkApiHealth();
// //       } else {
// //         _isApiReachable = false;
// //       }
      
// //       // Notify listeners if status changed
// //       if (wasConnected != _hasConnection) {
// //         _connectionController.add(_hasConnection);
// //       }
      
// //       if (wasApiReachable != _isApiReachable) {
// //         _apiReachableController.add(_isApiReachable);
// //       }
      
// //       print('🌐 Connection: ${_hasConnection ? 'ONLINE' : 'OFFLINE'}');
// //       print('📡 API: ${_isApiReachable ? 'REACHABLE' : 'NOT REACHABLE'}');
      
// //     } catch (e) {
// //       print('⚠️ Connection check error: $e');
// //       _hasConnection = false;
// //       _isApiReachable = false;
// //     }
// //   }

// //   // Check if API is reachable
// //   Future<bool> _checkApiHealth() async {
// //     try {
// //       final result = await _api.healthCheck();
// //       return result['success'] == true;
// //     } catch (e) {
// //       print('⚠️ API health check failed: $e');
// //       return false;
// //     }
// //   }

// //   // Quick check for internet connection
// //   Future<bool> hasInternet() async {
// //     try {
// //       final results = await _connectivity.checkConnectivity();
// //       return results.any((r) => r != ConnectivityResult.none);
// //     } catch (e) {
// //       return false;
// //     }
// //   }

// //   // Quick check for API reachability
// //   Future<bool> isApiCanBeReached() async {
// //     if (!await hasInternet()) return false;
// //     return await _checkApiHealth();
// //   }

// //   // Check both connection and API
// //   Future<bool> isFullyConnected() async {
// //     if (!await hasInternet()) return false;
// //     return await isApiCanBeReached();
// //   }

// //   // Dispose
// //   void dispose() {
// //     _connectionController.close();
// //     _apiReachableController.close();
// //   }
// // }



// import 'dart:async';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:http/http.dart' as http;
// import 'package:isetagcom/services/api_service.dart';

// class ConnectionChecker {
//   static final ConnectionChecker _instance = ConnectionChecker._internal();
//   factory ConnectionChecker() => _instance;
//   ConnectionChecker._internal();

//   final Connectivity _connectivity = Connectivity();
//   final ApiService _api = ApiService();
  
//   bool _hasConnection = false;
//   bool _isApiReachable = false;
  
//   // Cache mechanism to prevent spamming the health check
//   DateTime _lastApiCheckTime = DateTime.now().subtract(const Duration(minutes: 5));
//   static const Duration API_CHECK_COOLDOWN = Duration(seconds: 5);
//   static const Duration API_CHECK_TIMEOUT = Duration(seconds: 2); // CRITICAL: 2 sec max

//   final _connectionController = StreamController<bool>.broadcast();
//   Stream<bool> get connectionStream => _connectionController.stream;
  
//   final _apiReachableController = StreamController<bool>.broadcast();
//   Stream<bool> get apiReachableStream => _apiReachableController.stream;

//   bool get hasConnection => _hasConnection;
//   bool get isApiReachable => _isApiReachable;
//   bool get isConnected => _hasConnection && _isApiReachable;

//   Future<void> init() async {
//     await _checkConnection();
//     _connectivity.onConnectivityChanged.listen((_) {
//       _checkConnection();
//     });
//   }

//   Future<void> _checkConnection() async {
//     try {
//       final results = await _connectivity.checkConnectivity();
//       final bool wasConnected = _hasConnection;
//       final bool wasApiReachable = _isApiReachable;
      
//       _hasConnection = results.any((r) => r != ConnectivityResult.none);
      
//       // Only check API if we have internet AND enough time has passed since last check
//       if (_hasConnection) {
//         final now = DateTime.now();
//         if (now.difference(_lastApiCheckTime) >= API_CHECK_COOLDOWN) {
//           _lastApiCheckTime = now;
//           _isApiReachable = await _checkApiHealth();
//         }
//       } else {
//         _isApiReachable = false;
//       }
      
//       if (wasConnected != _hasConnection) _connectionController.add(_hasConnection);
//       if (wasApiReachable != _isApiReachable) _apiReachableController.add(_isApiReachable);
      
//       print('🌐 Connection: ${_hasConnection ? 'ONLINE' : 'OFFLINE'}');
//       print('📡 API: ${_isApiReachable ? 'REACHABLE' : 'NOT REACHABLE'}');
      
//     } catch (e) {
//       print('⚠️ Connection check error: $e');
//       _hasConnection = false;
//       _isApiReachable = false;
//     }
//   }

//   // Direct lightweight health check with a 2-second hard deadline
//   Future<bool> _checkApiHealth() async {
//     try {
//       // We bypass ApiService here to guarantee a short timeout. 
//       // Replace the IP with your PC's IP. 
//       final response = await http
//           .get(
//               Uri.parse('http://192.168.43.100:8000/campagne_api/ISETAG_COM.etablissements'))
//           .timeout(API_CHECK_TIMEOUT);

//       return response.statusCode == 200;
//     } catch (e) {
//       // If it times out, it's definitely a local network issue
//       print('⚠️ API health check failed (Timeout or Unreachable): $e');
//       return false;
//     }
//   }

//   Future<bool> hasInternet() async {
//     try {
//       final results = await _connectivity.checkConnectivity();
//       return results.any((r) => r != ConnectivityResult.none);
//     } catch (_) { return false; }
//   }

//   Future<bool> isFullyConnected() async {
//     if (!await hasInternet()) return false;
//     return await _checkApiHealth();
//   }

//   void dispose() {
//     _connectionController.close();
//     _apiReachableController.close();
//   }
// }


// lib/utils/connection_checker.dart
import 'dart:async';
import '../config/app_config.dart';
import '../services/api_service.dart';

class ConnectionChecker {
  static final ConnectionChecker _instance = ConnectionChecker._internal();
  factory ConnectionChecker() => _instance;
  ConnectionChecker._internal();

  bool _isConnected = false;
  bool _isApiReachable = false;
  Timer? _healthCheckTimer;
  final ApiService _api = ApiService();

  final _connectionController = StreamController<bool>.broadcast();
  final _apiReachableController = StreamController<bool>.broadcast();

  Stream<bool> get connectionStream => _connectionController.stream;
  Stream<bool> get apiReachableStream => _apiReachableController.stream;

  bool get isConnected => _isConnected;
  bool get isApiReachable => _isApiReachable;

  // ✅ Méthode d'initialisation
  Future<void> init() async {
    await checkConnection();
    _startPeriodicCheck();
  }

  // ✅ Vérification complète de la connexion
  Future<void> checkConnection() async {
    try {
      // Vérifier d'abord la connectivité réseau
      final networkAvailable = await _checkNetworkConnectivity();
      
      if (networkAvailable) {
        // Si réseau disponible, vérifier l'API
        final apiReachable = await _checkApiReachability();
        _isApiReachable = apiReachable;
        _isConnected = apiReachable; // Maintenant connecté = API accessible
      } else {
        _isConnected = false;
        _isApiReachable = false;
      }

      _connectionController.add(_isConnected);
      _apiReachableController.add(_isApiReachable);

      print('📶 Connection status - Network: $networkAvailable, API: ${_isApiReachable}');
    } catch (e) {
      print('❌ Error checking connection: $e');
      _isConnected = false;
      _isApiReachable = false;
      _connectionController.add(false);
      _apiReachableController.add(false);
    }
  }

  // ✅ Vérification de la connectivité réseau
  Future<bool> _checkNetworkConnectivity() async {
    try {
      // Utiliser un ping simple ou vérifier la connectivité
      // Vous pouvez utiliser connectivity_plus ici
      return true; // Temporairement true, à remplacer par votre logique
    } catch (e) {
      return false;
    }
  }

  // ✅ Vérification de l'accessibilité de l'API
  Future<bool> _checkApiReachability() async {
    try {
      // Utiliser la méthode healthCheck de l'API
      final response = await _api.healthCheck();
      return response == 200; // Ou vérifier le contenu
    } catch (e) {
      print('❌ API unreachable: $e');
      return false;
    }
  }

  // ✅ Vérification périodique
  void _startPeriodicCheck() {
    _healthCheckTimer?.cancel();
    _healthCheckTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => checkConnection(),
    );
  }

  // ✅ Forcer une vérification
  Future<void> refresh() async {
    await checkConnection();
  }

  // ✅ Nettoyage
  void dispose() {
    _healthCheckTimer?.cancel();
    _connectionController.close();
    _apiReachableController.close();
  }
}