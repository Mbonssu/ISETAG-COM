// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:timezone/timezone.dart' as tz;
// import 'package:timezone/data/latest.dart' as tz;
// import 'package:permission_handler/permission_handler.dart';

// class NotificationService {
//   static final NotificationService _instance = NotificationService._internal();
//   factory NotificationService() => _instance;
//   NotificationService._internal();

//   final FlutterLocalNotificationsPlugin _notifications =
//       FlutterLocalNotificationsPlugin();

//   Future<void> init() async {
//     // Initialiser timezone avec les données
//     tz.initializeTimeZones();

//     // Utiliser le fuseau horaire local du système
//     try {
//       tz.setLocalLocation(tz.local);
//     } catch (e) {
//       final location = tz.getLocation('Africa/Lagos');
//       tz.setLocalLocation(location);
//     }
//   }

//   Future<void> _requestPermissions() async {
//     if (await Permission.notification.isDenied) {
//       await Permission.notification.request();
//     }
//   }

//   /// Générer un ID valide (entre 0 et 2^31-1)
//   int _generateValidId(DateTime dateTime) {
//     int rawId = dateTime.millisecondsSinceEpoch % 2147483647;
//     rawId = (rawId % 2147482647) + 1000;
//     return rawId;
//   }

//   Future<void> showNotification({
//     required String title,
//     required String body,
//     DateTime? scheduledTime,
//     String? payload,
//   }) async {
//     final int id = scheduledTime != null
//         ? _generateValidId(scheduledTime)
//         : _generateValidId(DateTime.now());

//     const AndroidNotificationDetails androidDetails =
//         AndroidNotificationDetails(
//       'relance_channel',
//       'Notifications de relance',
//       channelDescription: 'Notifications pour les relances de prospects',
//       importance: Importance.high,
//       priority: Priority.high,
//       playSound: true,
//       enableVibration: true,
//       // showBadge: true,
//       color: Color(0xFF2E7D32), // Vert ISETAG
//       colorized: true,
//       largeIcon: DrawableResourceAndroidBitmap('@mipmap/app_icon'),
//     );

//     const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
//       presentAlert: true,
//       presentBadge: true,
//       presentSound: true,
//     );

//     const NotificationDetails details = NotificationDetails(
//       android: androidDetails,
//       iOS: iosDetails,
//     );

//     if (scheduledTime != null) {
//       try {
//         final scheduledDate = tz.TZDateTime.from(scheduledTime, tz.local);
//         await _notifications.zonedSchedule(
//           id: id,
//           title: title,
//           body: body,
//           scheduledDate: scheduledDate,
//           notificationDetails: details,
//           androidScheduleMode: AndroidScheduleMode.alarmClock,
//           matchDateTimeComponents: DateTimeComponents.dateAndTime,
//           payload: payload,
//         );
//       } catch (e) {
//         print('Erreur programmation notification: $e');
//         await _notifications.show(
//           id: id,
//           title: title,
//           body: body,
//           notificationDetails: details,
//           payload: payload,
//         );
//       }
//     } else {
//       await _notifications.show(
//         id: id,
//         title: title,
//         body: body,
//         notificationDetails: details,
//         payload: payload,
//       );
//     }
//   }

//   // ✅ AJOUTER CETTE MÉTHODE
//   Future<void> showOverdueNotification({
//     required String prospectName,
//     required String prospectId,
//   }) async {
//     await showNotification(
//       title: '⚠️ Relance en retard',
//       body: 'La relance pour $prospectName est en retard',
//       payload: 'overdue_$prospectId',
//     );
//   }

//   // ✅ AJOUTER CETTE MÉTHODE
//   Future<void> showReminderNotification({
//     required String prospectName,
//     required String prospectId,
//     DateTime? scheduledTime,
//   }) async {
//     await showNotification(
//       title: '🔄 Relance programmée',
//       body: 'N\'oubliez pas de relancer $prospectName',
//       scheduledTime: scheduledTime,
//       payload: 'prospect_$prospectId',
//     );
//   }

//   Future<void> cancelNotification(int id) async {
//     await _notifications.cancel(id: id);
//   }

//   Future<void> cancelAllNotifications() async {
//     await _notifications.cancelAll();
//   }
// }


// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:timezone/data/latest.dart' as tz;
// import 'package:timezone/timezone.dart' as tz;

// class NotificationService {
//   NotificationService._();

//   static final NotificationService instance = NotificationService._();

//   final FlutterLocalNotificationsPlugin plugin =
//       FlutterLocalNotificationsPlugin();

//   Future<void> initialize() async {
//     tz.initializeTimeZones();

//     const android = AndroidInitializationSettings('@mipmap/ic_launcher');

//     const settings = InitializationSettings(
//       android: android,
//     );

//     await plugin.initialize(settings: settings);

//     const channel = AndroidNotificationChannel(
//       'relance_channel',
//       'Relances Prospect',
//       description: 'Notifications des relances',
//       importance: Importance.max,
//     );

//     await plugin
//         .resolvePlatformSpecificImplementation<
//             AndroidFlutterLocalNotificationsPlugin>()
//         ?.createNotificationChannel(channel);

//     await plugin
//         .resolvePlatformSpecificImplementation<
//             AndroidFlutterLocalNotificationsPlugin>()
//         ?.requestNotificationsPermission();
//   }

//   int notificationId(String prospectId) {
//     return prospectId.hashCode & 0x7fffffff;
//   }

//   NotificationDetails get _details => const NotificationDetails(
//         android: AndroidNotificationDetails(
//           'relance_channel',
//           'Relances Prospect',
//           channelDescription: 'Notifications des relances',
//           importance: Importance.max,
//           priority: Priority.high,
//         ),
//       );

//   Future<void> showNow({
//     required String title,
//     required String body,
//   }) async {
//     await plugin.show(
//       id: DateTime.now().millisecondsSinceEpoch ~/ 1000,
//       // title,
//       // body,
//       notificationDetails: _details,
//     );
//   }

//   Future<void> scheduleReminder({
//     required String prospectId,
//     required String prospectName,
//     required DateTime date,
//   }) async {
//     await plugin.zonedSchedule(
//       id: notificationId(prospectId),
//       // "🔔 Relance Prospect",
//       // "N'oubliez pas de relancer $prospectName",
//       scheduledDate: tz.TZDateTime.from(date, tz.local),
//       notificationDetails: _details,
//       androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
//       payload: prospectId,
//     );
//   }

//   Future<void> cancelReminder(String prospectId) async {
//     await plugin.cancel(id: notificationId(prospectId));
//   }

//   Future<void> cancelAll() async {
//     await plugin.cancelAll();
//   }

//   Future<List<PendingNotificationRequest>> pendingNotifications() async {
//     return plugin.pendingNotificationRequests();
//   }
// }



import 'dart:typed_data';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';

// ⚠️ FONCTION TOP-LEVEL pour le background (hors de la classe)
@pragma('vm:entry-point')
void onDidReceiveBackgroundNotificationResponse(NotificationResponse details) {
  print('📱 Notification en arrière-plan reçue: ${details.payload}');
}

class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  bool _isInitialized = false;

  // Callback pour les clics sur les notifications
  Function(String?)? _onNotificationTap;

  // ─── Initialisation ──────────────────────────────────────────────────────

  Future<void> initialize({Function(String?)? onNotificationTap}) async {
    if (_isInitialized) return;

    _onNotificationTap = onNotificationTap;

    // Initialiser les fuseaux horaires
    tz.initializeTimeZones();

    // Configuration Android
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');

    // Configuration iOS
    const ios = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
      defaultPresentAlert: true,
      defaultPresentBadge: true,
      defaultPresentSound: true,
    );

    const settings = InitializationSettings(
      android: android,
      iOS: ios,
    );

    // Initialiser le plugin
    await plugin.initialize(
      settings: settings,
      onDidReceiveNotificationResponse: (details) {
        _handleNotificationTap(details);
      },
      onDidReceiveBackgroundNotificationResponse: onDidReceiveBackgroundNotificationResponse,
    );

    // Créer les canaux Android
    await _createAndroidChannels();

    // Demander les permissions
    await _requestPermissions();

    _isInitialized = true;

    print('✅ NotificationService initialisé avec succès');
  }

  // ─── Canaux Android ──────────────────────────────────────────────────────

  Future<void> _createAndroidChannels() async {
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    if (android == null) return;

    // Canal pour les relances
    final relanceChannel = AndroidNotificationChannel(
      'relance_channel',
      'Relances Prospect',
      description: 'Notifications des relances de prospects',
      importance: Importance.max,
      enableVibration: true,
      vibrationPattern: Int64List.fromList(const [0, 500, 200, 500]),
      playSound: true,
    );

    // Canal pour les rappels
    final reminderChannel = AndroidNotificationChannel(
      'reminder_channel',
      'Rappels',
      description: 'Rappels des événements importants',
      importance: Importance.high,
      enableVibration: true,
      vibrationPattern: Int64List.fromList(const [0, 300, 200, 300]),
    );

    // Canal pour les notifications générales
    const generalChannel = AndroidNotificationChannel(
      'general_channel',
      'Notifications Générales',
      description: 'Notifications générales de l\'application',
      importance: Importance.defaultImportance,
    );

    await android.createNotificationChannel(relanceChannel);
    await android.createNotificationChannel(reminderChannel);
    await android.createNotificationChannel(generalChannel);

    print('✅ Canaux Android créés avec succès');
  }

  // ─── Permissions ──────────────────────────────────────────────────────────

  Future<void> _requestPermissions() async {
    final android = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    if (android != null) {
      await android.requestNotificationsPermission();
    }

    final ios = plugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();

    if (ios != null) {
      await ios.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
    }

    print('✅ Permissions de notification demandées');
  }

  // ─── Gestion des clics ────────────────────────────────────────────────────

  void _handleNotificationTap(NotificationResponse details) {
    final payload = details.payload;

    // Marquer la notification comme lue
    _markNotificationAsRead(payload);

    if (_onNotificationTap != null) {
      _onNotificationTap!(payload);
    }
  }

  Future<void> _markNotificationAsRead(String? payload) async {
    if (payload == null) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      final readNotifications = prefs.getStringList('read_notifications') ?? [];

      if (!readNotifications.contains(payload)) {
        readNotifications.add(payload);
        await prefs.setStringList('read_notifications', readNotifications);
      }
    } catch (e) {
      print('❌ Erreur lors du marquage de la notification: $e');
    }
  }

  // ─── Utilitaires ──────────────────────────────────────────────────────────

  int _getNotificationId(String prospectId) {
    return prospectId.hashCode & 0x7fffffff;
  }

  NotificationDetails _getDetails(String channelId) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelId == 'relance_channel'
            ? 'Relances Prospect'
            : channelId == 'reminder_channel'
                ? 'Rappels'
                : 'Notifications Générales',
        channelDescription: channelId == 'relance_channel'
            ? 'Notifications des relances de prospects'
            : channelId == 'reminder_channel'
                ? 'Rappels des événements importants'
                : 'Notifications générales de l\'application',
        importance: channelId == 'relance_channel'
            ? Importance.max
            : channelId == 'reminder_channel'
                ? Importance.high
                : Importance.defaultImportance,
        priority: channelId == 'relance_channel'
            ? Priority.high
            : channelId == 'reminder_channel'
                ? Priority.max
                : Priority.defaultPriority,
        enableVibration: true,
        vibrationPattern: Int64List.fromList([0, 500, 200, 500]),
        playSound: true,
        styleInformation: const BigTextStyleInformation(''),
        autoCancel: true,
        timeoutAfter: 60000, // 60 secondes
        showWhen: true,
        when: DateTime.now().millisecondsSinceEpoch,
      ),
      iOS: const DarwinNotificationDetails(
        categoryIdentifier: 'relance_category',
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        interruptionLevel: InterruptionLevel.timeSensitive,
      ),
    );
  }

  // ─── Afficher une notification immédiatement ────────────────────────────

  Future<void> showNow({
    required String title,
    required String body,
    String? payload,
    String channelId = 'general_channel',
  }) async {
    try {
      final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;

      await plugin.show(
        id: id,
        title: title,
        body: body,
        notificationDetails: _getDetails(channelId),
        payload: payload,
      );

      print('✅ Notification immédiate affichée: "$title"');
    } catch (e) {
      print('❌ Erreur lors de l\'affichage de la notification: $e');
    }
  }

  // ─── Programmer une notification ─────────────────────────────────────────

  Future<void> scheduleReminder({
    required String prospectId,
    required String prospectName,
    required DateTime date,
    String? comment,
  }) async {
    try {
      // Vérifier que la date est dans le futur
      if (date.isBefore(DateTime.now())) {
        print('⚠️ La date de relance est déjà passée');
        return;
      }

      final id = _getNotificationId(prospectId);

      // Annuler toute notification existante pour ce prospect
      await cancelReminder(prospectId);

      final scheduledDate = tz.TZDateTime.from(date, tz.local);

      final title = '🔔 Relance Prospect';
      final body = comment?.isNotEmpty == true
          ? 'Relancer $prospectName: $comment'
          : 'N\'oubliez pas de relancer $prospectName';

      await plugin.zonedSchedule(
        id: id,
        title: title,
        body: body,
        scheduledDate: scheduledDate,
        notificationDetails: _getDetails('relance_channel'),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        payload: prospectId,
      );

      print('✅ Notification programmée pour $prospectName le ${date.toString()}');
    } catch (e) {
      print('❌ Erreur lors de la programmation: $e');
    }
  }

  // ─── Programmer une notification répétitive ─────────────────────────────

  Future<void> scheduleRepeatingReminder({
    required String prospectId,
    required String prospectName,
    required DateTime startDate,
    required Duration interval,
    String? comment,
  }) async {
    try {
      final id = _getNotificationId(prospectId);

      await cancelReminder(prospectId);

      final scheduledDate = tz.TZDateTime.from(startDate, tz.local);

      final title = '🔔 Rappel Relance';
      final body = comment?.isNotEmpty == true
          ? 'Relancer $prospectName: $comment'
          : 'Rappel pour relancer $prospectName';

      await plugin.zonedSchedule(
        id: id,
        title: title,
        body: body,
        scheduledDate: scheduledDate,
        notificationDetails: _getDetails('reminder_channel'),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        payload: prospectId,
        matchDateTimeComponents: DateTimeComponents.time,
      );

      print('✅ Rappel répétitif programmé pour $prospectName');
    } catch (e) {
      print('❌ Erreur lors de la programmation répétitive: $e');
    }
  }

  // ─── Annuler une notification ────────────────────────────────────────────

  Future<void> cancelReminder(String prospectId) async {
    try {
      final id = _getNotificationId(prospectId);
      await plugin.cancel(id: id);
      print('✅ Notification annulée pour le prospect $prospectId');
    } catch (e) {
      print('❌ Erreur lors de l\'annulation: $e');
    }
  }

  // ─── Annuler toutes les notifications ────────────────────────────────────

  Future<void> cancelAll() async {
    try {
      await plugin.cancelAll();
      print('✅ Toutes les notifications ont été annulées');
    } catch (e) {
      print('❌ Erreur lors de l\'annulation: $e');
    }
  }

  // ─── Récupérer les notifications en attente ─────────────────────────────

  Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    try {
      return await plugin.pendingNotificationRequests();
    } catch (e) {
      print('❌ Erreur lors de la récupération des notifications: $e');
      return [];
    }
  }

  // ─── Vérifier si une notification est programmée ─────────────────────────

  Future<bool> isNotificationScheduled(String prospectId) async {
    try {
      final pending = await getPendingNotifications();
      final id = _getNotificationId(prospectId);
      return pending.any((n) => n.id == id);
    } catch (e) {
      return false;
    }
  }

  // ─── Notifications spécifiques ───────────────────────────────────────────

  Future<void> showRelanceNotification({
    required String prospectName,
    String? prospectId,
  }) async {
    const title = '🔔 Relance recommandée';
    final body = 'Le prospect $prospectName devrait être relancé aujourd\'hui !';

    await showNow(
      title: title,
      body: body,
      payload: prospectId,
      channelId: 'relance_channel',
    );
  }

  Future<void> showNewProspectNotification({
    required String prospectName,
    String? prospectId,
  }) async {
    const title = '📝 Nouveau Prospect';
    final body = '$prospectName a été ajouté à votre liste de prospection';

    await showNow(
      title: title,
      body: body,
      payload: prospectId,
      channelId: 'general_channel',
    );
  }

  Future<void> showFollowUpNotification({
    required String prospectName,
    String? prospectId,
  }) async {
    const title = '📋 Suivi recommandé';
    final body = 'Pensez à faire un suivi avec $prospectName';

    await showNow(
      title: title,
      body: body,
      payload: prospectId,
      channelId: 'reminder_channel',
    );
  }

  Future<void> showOverdueNotification({
    required String prospectName,
    String? prospectId,
  }) async {
    const title = '⚠️ Relance en retard';
    final body = 'La relance pour $prospectName est en retard !';

    await showNow(
      title: title,
      body: body,
      payload: prospectId,
      channelId: 'relance_channel',
    );
  }
}