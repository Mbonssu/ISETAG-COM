// ignore_for_file: deprecated_member_use

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:isetagcom/models/source.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/fiche.dart';
import '../models/localStorage/local_storage.dart';
import '../routes/app_router.dart';
import '../services/translation_service.dart';
import '../utils/status.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();

    _initApp();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.elasticOut),
    );

    _animationController.forward();

    Timer(const Duration(seconds: 3), _navigateToNextScreen);
  }

  Future<void> _initApp() async {
    await LocalStorage.instance.init();
    await TranslationService.init();
    await _ensureDefaultFicheExists();
  }

  // ─── Vérification et création de la fiche par défaut ────────────────────
  Future<void> _ensureDefaultFicheExists() async {
    try {
      // Vérifier si une fiche existe déjà
      final existingFiches = await LocalStorage.instance.getAllFiches();
      
      if (existingFiches.isEmpty) {
        print('📝 Aucune fiche trouvée, création de la fiche par défaut...');
        
        // Créer une source par défaut
        final now = DateTime.now();
        final defaultSource = Source(
          idSource: 'src_default_${now.millisecondsSinceEpoch}',
          libelleSource: 'Prospection terrain',
          createdAt: now,
          syncState: SyncState.pending,
        );
        
        // Sauvegarder la source
        await LocalStorage.instance.saveSource(defaultSource);
        print('✅ Source par défaut créée: ${defaultSource.libelleSource}');

        // Créer la fiche par défaut liée à la source
        final defaultFiche = Fiche(
          idFiche: 'fiche_default_${now.millisecondsSinceEpoch}',
          idSrc: defaultSource.idSource,
          createdAt: now, 
          dateCollecte: DateTime.now(), 
          isCurrent: true,
          syncState: SyncState.pending,
        );
        
        // Sauvegarder la fiche
        await LocalStorage.instance.saveFiche(defaultFiche);
        print('✅ Fiche par défaut créée avec succès');
        print('📋 ID Fiche: ${defaultFiche.idFiche}');
        print('📋 ID Source: ${defaultFiche.idSrc}');
      } else {
        print('✅ Fiche existante trouvée: ${existingFiches.length} fiche(s)');
        // Afficher les fiches existantes pour vérification
        for (var fiche in existingFiches) {
          print('  - Fiche ID: ${fiche.idFiche}, Source: ${fiche.idSrc}, Date: ${fiche.dateCollecte}');
        }
      }
    } catch (e) {
      print('❌ Erreur lors de la vérification/création de la fiche: $e');
    }
  }

  Future<void> _navigateToNextScreen() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool('is_logged_in') ?? false;

    if (mounted) {
      if (isLoggedIn) {
        Navigator.of(context).pushReplacementNamed(AppRoutes.main);
      } else {
        Navigator.of(context).pushReplacementNamed(AppRoutes.main);
        // Navigator.of(context).pushReplacementNamed(AppRoutes.login);
      }
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2E7D32),
              Color(0xFF1B5E20),
              Color(0xFF0A3D13),
            ],
          ),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return FadeTransition(
                opacity: _fadeAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFFF9A825), Color(0xFFF57F17)],
                          ),
                          borderRadius: BorderRadius.circular(35),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Container(
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    'assets/images/app_icon.png'),
                                fit: BoxFit.cover,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(60))
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Text(
                        'ISETAG',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: 4,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Prospection & Communication',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 50),
                      const CircularProgressIndicator(
                        valueColor:
                            AlwaysStoppedAnimation<Color>(Color(0xFFF9A825)),
                        strokeWidth: 3,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'loading'.tr,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white60,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}