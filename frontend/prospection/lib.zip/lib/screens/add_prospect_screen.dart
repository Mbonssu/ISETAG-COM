// ignore_for_file: prefer_final_fields, avoid_print, use_build_context_synchronously, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:isetagcom/models/classe.dart';
import 'package:isetagcom/models/pros.dart';
import '../models/etablissement.dart';
import '../models/fiche.dart';
import '../models/interet_filiere.dart';
import '../models/localStorage/local_storage.dart';
import '../models/source.dart';
import '../models/specialite.dart';
import '../services/export_service.dart';
import '../services/loading_service.dart';
import '../services/translation_service.dart';
import '../utils/status.dart';
import '../utils/themes/glass_theme.dart';

class AddProspectScreen extends StatefulWidget {
  const AddProspectScreen({super.key});

  @override
  State<AddProspectScreen> createState() => _AddProspectScreenState();
}

class _AddProspectScreenState extends State<AddProspectScreen> {
  @override
  void initState() {
    super.initState();
    _initForm();
    _loadFromDb();
  }

  // ─── Chargement des données depuis Isar ──────────────────────────────────
  Future<void> _loadFromDb() async {
    // Seed des classes et spécialités si la base est vide
    await LocalStorage.instance.seedClassesIfEmpty();
    await LocalStorage.instance.seedSpecialtiesIfEmpty();

    final ets = await LocalStorage.instance.getAllEtablissements();
    final cls = await LocalStorage.instance.getAllClasses();
    final specs = await LocalStorage.instance.getAllSpecialites();

    setState(() {
      // Stocker les objets complets pour filtrer par type
      _allEtablissements = ets;

      // Mettre à jour les listes d'affichage
      _etablissementNames.clear();
      for (final e in ets) {
        if (!_etablissementNames.contains(e.nomEtablissement)) {
          _etablissementNames.add(e.nomEtablissement);
        }
      }

      // Mettre à jour les classes - utiliser .tr pour afficher la traduction
      _classes.clear();
      _classKeys.clear();
      for (final c in cls) {
        _classKeys.add(c.libelleClasse); // Stocker la clé
        final translatedName = c.libelleClasse.tr; // Afficher la traduction
        if (!_classes.contains(translatedName)) {
          _classes.add(translatedName);
        }
      }

      // Recharger les spécialités après seed
      _specialites.clear();
      _specialityKeys.clear();
      for (final s in specs) {
        _specialityKeys.add(s.libelleSpecialite); // Stocker la clé
        final translatedName = s.libelleSpecialite.tr; // Afficher la traduction
        if (!_specialites.contains(translatedName)) {
          _specialites.add(translatedName);
        }
      }

      // Appliquer le filtre en fonction du niveau actuel
      _filteredEtablissementNames = _getFilteredEtablissementNames();
    });
  }

  final _formKey = GlobalKey<FormState>();

  // Controllers pour Prospect
  final _nomCompletCtrl = TextEditingController();
  final _telephoneCtrl = TextEditingController();
  final _nomParentCtrl = TextEditingController();
  final _telephoneParentCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _concerneCtrl = TextEditingController();
  final _adresseCtrl = TextEditingController();
  final _relanceCtrl = TextEditingController();

  // Controller pour commentaire
  final _commentaireCtrl = TextEditingController();

  // Liste des intérêts (plusieurs filières)
  final List<Map<String, dynamic>> _interetsList = [];

  // Controllers pour ajouter un intérêt
  final TextEditingController _newOrdrePreferenceCtrl = TextEditingController();
  final TextEditingController _newNiveauInteretCtrl = TextEditingController();
  final TextEditingController _newCommentaireInteretCtrl =
      TextEditingController();

  // Variables pour les sélections
  String? _selectedSpecialiteForInteret;
  String _selectedSexe = '';
  String _selectedTypeProspect = '';
  String? _selectedEtablissement;
  String? _selectedClasse;
  String _selectedSource = '';
  String _selectedNiveauEtude = '';
  int _scoreInteret = 5;

  DateTime now = DateTime.now();
  DateTime? _date_relance;

  // Sections expansion state
  final Map<String, bool> _sectionsExpanded = {
    'personnelles': true,
    'academiques': false,
    'interet': false,
    'commentaires': false,
    'relance': false,
  };

  // ─── Listes dynamiques ────────────────────────────────────────────────────
  List<Etablissement> _allEtablissements = [];
  final List<String> _etablissementNames = [];
  List<String> _filteredEtablissementNames = [];

  final List<String> _classes = [];
  List<String> _classKeys = [];

  final List<String> _specialites = [];
  List<String> _specialityKeys = [];

  List<String> _sources = [
    'Réseaux sociaux',
    'Recommandation',
    'Site web',
    'Événement',
    'Prospection terrain',
    'Partenariat',
  ];

  final List<String> _sexeOptions = ['Masculin', 'Féminin'];
  final List<String> _typeProspectOptions = ['Étudiant', 'Éleve'];
  final List<String> _niveauEtudeOptions = [
    'Baccalauréat',
    'BTS 1',
    'BTS 2',
    'Licence',
    'Master 1',
  ];

  // ─── Helpers ──────────────────────────────────────────────────────────────

  bool _shouldShowClassField() {
    return _selectedNiveauEtude == 'Baccalauréat' &&
        _selectedTypeProspect == 'Éleve';
  }

  List<String> _getFilteredEtablissementNames() {
    final isBac = _selectedNiveauEtude == 'Baccalauréat';
    final targetType = isBac ? 'secondaire' : 'superieur';

    if (_allEtablissements.isEmpty) {
      return _etablissementNames;
    }

    return _allEtablissements
        .where((e) => e.typeEtablissement == targetType)
        .map((e) => e.nomEtablissement)
        .toList();
  }

  void _initForm() {
    _nomCompletCtrl.text = 'Reo';
    _telephoneCtrl.text = '3212';
    _nomParentCtrl.text = 'Papa';
    _telephoneParentCtrl.text = '657483643';
    _emailCtrl.text = '@gmail.com';
    _concerneCtrl.text = _typeProspectOptions[0];
    _adresseCtrl.text = ' city';
    _commentaireCtrl.text = 'Right';

    _selectedEtablissement =
        _etablissementNames.isNotEmpty ? _etablissementNames[0] : null;
    _selectedClasse = _classes.isNotEmpty ? _classes[0] : null;
    _selectedNiveauEtude = _niveauEtudeOptions[0];
    _relanceCtrl.text = '';
    _selectedSexe = _sexeOptions[0];
    _selectedTypeProspect = _typeProspectOptions[1];
    _selectedSource = _sources[0];

    _newOrdrePreferenceCtrl.text = '1';
    _newNiveauInteretCtrl.text = '1';
    _newCommentaireInteretCtrl.text = 'no_comment'.tr;

    if (_specialites.isNotEmpty) {
      _selectedSpecialiteForInteret = _specialites[0];
    }

    _filteredEtablissementNames = _getFilteredEtablissementNames();
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageBackground(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                physics: const BouncingScrollPhysics(),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Section 1: Informations Personnelles
                      _buildExpandableSection(
                        title: 'personal_info'.tr,
                        icon: Icons.person_outline,
                        isExpanded: _sectionsExpanded['personnelles']!,
                        onToggle: () => _toggleSection('personnelles'),
                        children: [
                          _buildTextField(
                              controller: _nomCompletCtrl,
                              label: 'full_name'.tr,
                              hint: 'enter_full_name'.tr,
                              icon: Icons.person_outline,
                              required: true),
                          const SizedBox(height: 12),
                          _buildTextField(
                              controller: _telephoneCtrl,
                              label: 'phone'.tr,
                              hint: 'enter_phone'.tr,
                              icon: Icons.phone_outlined,
                              keyboardType: TextInputType.phone,
                              required: true),
                          const SizedBox(height: 12),
                          _buildTextField(
                              controller: _nomParentCtrl,
                              label: 'name_par'.tr,
                              hint: 'enter_full_name'.tr,
                              icon: Icons.person_outline,
                              required: true),
                          const SizedBox(height: 12),
                          _buildTextField(
                              controller: _telephoneParentCtrl,
                              label: 'phone_par'.tr,
                              hint: 'enter_phone'.tr,
                              icon: Icons.phone_outlined,
                              keyboardType: TextInputType.phone,
                              required: true),
                          const SizedBox(height: 12),
                          _buildTextField(
                              controller: _emailCtrl,
                              label: 'email'.tr,
                              hint: 'enter_email'.tr,
                              icon: Icons.email_outlined,
                              keyboardType: TextInputType.emailAddress),
                          const SizedBox(height: 12),
                          _buildDropdownField(
                            value: _selectedSexe,
                            label: 'gender'.tr,
                            hint: 'select'.tr,
                            icon: Icons.man_2,
                            items: _sexeOptions,
                            onChanged: (v) =>
                                setState(() => _selectedSexe = v!),
                          ),
                          const SizedBox(height: 12),
                          _buildDropdownField(
                            value: _selectedNiveauEtude,
                            label: 'education_level'.tr,
                            hint: 'select'.tr,
                            icon: Icons.school_outlined,
                            items: _niveauEtudeOptions,
                            onChanged: (v) {
                              setState(() {
                                _selectedNiveauEtude = v!;
                                _filteredEtablissementNames =
                                    _getFilteredEtablissementNames();
                                if (_selectedEtablissement != null &&
                                    !_filteredEtablissementNames
                                        .contains(_selectedEtablissement)) {
                                  _selectedEtablissement = null;
                                }
                                if (!_shouldShowClassField()) {
                                  _selectedClasse = null;
                                }
                              });
                            },
                          ),
                          const SizedBox(height: 12),
                          _buildDropdownField(
                            value: _selectedTypeProspect,
                            label: 'who_is_prospect'.tr,
                            hint: 'select'.tr,
                            icon: Icons.category_outlined,
                            items: _typeProspectOptions,
                            onChanged: (v) {
                              setState(() {
                                _selectedTypeProspect = v!;
                                if (!_shouldShowClassField()) {
                                  _selectedClasse = null;
                                }
                              });
                            },
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                              controller: _adresseCtrl,
                              label: 'address'.tr,
                              hint: 'full_address'.tr,
                              icon: Icons.location_on_outlined),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Section 2: Informations académiques
                      _buildExpandableSection(
                        title: 'academic_info'.tr,
                        icon: Icons.business_outlined,
                        isExpanded: _sectionsExpanded['academiques']!,
                        onToggle: () => _toggleSection('academiques'),
                        children: [
                          _buildEntityPickerField(
                            value: _selectedEtablissement,
                            label: 'establishment'.tr,
                            hint: 'select_or_add'.tr,
                            icon: Icons.school_outlined,
                            entityType: 'etablissement',
                            items: _filteredEtablissementNames,
                            onChanged: (value) =>
                                setState(() => _selectedEtablissement = value),
                          ),
                          if (_shouldShowClassField()) ...[
                            const SizedBox(height: 12),
                            _buildEntityPickerField(
                              value: _selectedClasse,
                              label: 'class'.tr,
                              hint: 'select_or_add'.tr,
                              icon: Icons.class_outlined,
                              entityType: 'classe',
                              items: _classes,
                              onChanged: (value) =>
                                  setState(() => _selectedClasse = value),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Section 3: Intérêt et provenance
                      _buildExpandableSection(
                        title: 'interest_source'.tr,
                        icon: Icons.insights_outlined,
                        isExpanded: _sectionsExpanded['interet']!,
                        onToggle: () => _toggleSection('interet'),
                        children: [
                          _buildDropdownField(
                            value: _selectedSource,
                            label: 'source'.tr,
                            hint: 'select_or_add'.tr,
                            icon: Icons.sensors_rounded,
                            items: _sources,
                            onChanged: (value) =>
                                setState(() => _selectedSource = value!),
                            onAdd: (newValue) {
                              setState(() {
                                _sources.add(newValue);
                                _selectedSource = newValue;
                              });
                            },
                          ),
                          const SizedBox(height: 12),
                          _buildInteretsListSection(),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Section 4: Commentaires
                      _buildExpandableSection(
                        title: 'comments'.tr,
                        icon: Icons.comment_outlined,
                        isExpanded: _sectionsExpanded['commentaires']!,
                        onToggle: () => _toggleSection('commentaires'),
                        children: [
                          _buildTextField(
                            controller: _commentaireCtrl,
                            label: 'general_comment'.tr,
                            hint: 'add_observations'.tr,
                            icon: Icons.comment_outlined,
                            maxLines: 3,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Section 5: Relance
                      _buildExpandableSection(
                        title: 'schedule_followup'.tr,
                        icon: Icons.schedule_rounded,
                        isExpanded: _sectionsExpanded['relance']!,
                        onToggle: () => _toggleSection('relance'),
                        children: [
                          _buildDateTimeField(
                            controller: _relanceCtrl,
                            label: 'followup_date'.tr,
                            hint: 'schedule_followup'.tr,
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),

                      // Action buttons
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                side: BorderSide(color: Colors.grey.shade400),
                              ),
                              child: Text('cancel'.tr,
                                  style: const TextStyle(fontSize: 16)),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: _saveProspect,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF2E7D32),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text('save'.tr,
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white)),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Section toggle ───────────────────────────────────────────────────────

  void _toggleSection(String section) =>
      setState(() => _sectionsExpanded[section] = !_sectionsExpanded[section]!);

  // ─── Expandable section wrapper ───────────────────────────────────────────

  Widget _buildExpandableSection({
    required String title,
    required IconData icon,
    required bool isExpanded,
    required VoidCallback onToggle,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onToggle,
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Icon(icon, size: 22, color: const Color(0xFF2E7D32)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(title,
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF1B5E20))),
                    ),
                    Icon(isExpanded ? Icons.expand_less : Icons.expand_more,
                        color: Colors.grey.shade600, size: 24),
                  ],
                ),
              ),
            ),
          ),
          if (isExpanded)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: children),
            ),
        ],
      ),
    );
  }

  // ─── Intérêts section ─────────────────────────────────────────────────────

  Widget _buildInteretsListSection() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_interetsList.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text('selected_specialties'.tr,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF1B5E20))),
            ),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _interetsList.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final interet = _interetsList[index];
                return ListTile(
                  dense: true,
                  leading: CircleAvatar(
                    radius: 14,
                    backgroundColor: const Color(0xFF2E7D32).withOpacity(0.1),
                    child: Text('${index + 1}',
                        style: const TextStyle(
                            color: Color(0xFF2E7D32),
                            fontWeight: FontWeight.bold,
                            fontSize: 12)),
                  ),
                  title: Text(interet['specialite'],
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 13)),
                  subtitle: Text(
                    'order_preference'
                        .tr
                        .replaceFirst(
                            '{order}', '${interet['ordrePreference']}')
                        .replaceFirst('{level}', '${interet['niveauInteret']}'),
                    style: const TextStyle(fontSize: 11),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: Colors.red, size: 18),
                    onPressed: () => setState(() {
                      _interetsList.removeAt(index);
                      for (int i = 0; i < _interetsList.length; i++) {
                        _interetsList[i]['ordrePreference'] = i + 1;
                      }
                    }),
                  ),
                  onTap: () => _showEditInteretDialog(index),
                );
              },
            ),
            const Divider(),
          ],
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('add_specialty'.tr,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87)),
                const SizedBox(height: 12),
                // Utilisation du même sélecteur en bottom sheet pour les spécialités
                _buildEntityPickerField(
                  value: _selectedSpecialiteForInteret,
                  label: 'specialty_field'.tr,
                  hint: 'select_specialty'.tr,
                  icon: Icons.school_outlined,
                  entityType: 'specialite',
                  items: _specialites
                      .where((spec) =>
                          !_interetsList.any((i) => i['specialite'] == spec))
                      .toList(),
                  onChanged: (value) =>
                      setState(() => _selectedSpecialiteForInteret = value),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    // Expanded(
                    //     child: _buildSmallTextField(
                    //   controller: _newOrdrePreferenceCtrl,
                    //   label: 'order'.tr,
                    //   hint: 'order_hint'.tr,
                    //   icon: Icons.format_list_numbered,
                    //   keyboardType: TextInputType.number,
                    // )),
                    // const SizedBox(width: 12),
                    Expanded(
                        child: _buildSmallTextField(
                      controller: _newNiveauInteretCtrl,
                      label: 'level'.tr,
                      hint: 'level_hint'.tr,
                      icon: Icons.star_outline,
                      keyboardType: TextInputType.number,
                    )),
                  ],
                ),
                const SizedBox(height: 12),
                _buildSmallTextField(
                  controller: _newCommentaireInteretCtrl,
                  label: 'comment'.tr,
                  hint: 'specify_interest'.tr,
                  icon: Icons.comment_outlined,
                  maxLines: 2,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _clearInteretForm,
                        icon: const Icon(Icons.clear, size: 16),
                        label: Text('clear'.tr),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _addInteret,
                        icon: const Icon(Icons.add, size: 16),
                        label: Text('add'.tr),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2E7D32),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _addInteret() {
    final specialite = _selectedSpecialiteForInteret;
    final ordrePreference = _interetsList.length +
        1; //int.tryParse(_newOrdrePreferenceCtrl.text.trim());
    final niveauInteret = int.tryParse(_newNiveauInteretCtrl.text.trim());

    if (specialite == null || specialite.isEmpty) {
      _showSnackBar('select_specialty_warning'.tr, Colors.orange, 5);
      return;
    }
    // if (ordrePreference == null || ordrePreference < 1) {
    //   _showSnackBar('invalid_order'.tr, Colors.orange, 5);
    //   return;
    // }
    if (niveauInteret == null || niveauInteret < 1 || niveauInteret > 10) {
      _showSnackBar('invalid_level'.tr, Colors.orange, 5);
      return;
    }
    if (_interetsList.any((i) => i['ordrePreference'] == ordrePreference)) {
      _showSnackBar('order_exists'.tr, Colors.orange, 5);
      return;
    }
    if (_interetsList.any((i) => i['specialite'] == specialite)) {
      _showSnackBar('specialty_exists'.tr, Colors.orange, 5);
      return;
    }

    // Trouver la clé correspondante
    String? key;
    for (final specKey in _specialityKeys) {
      if (specKey.tr == specialite) {
        key = specKey;
        break;
      }
    }
    final specialiteKey = key ?? specialite;

    setState(() {
      _interetsList.add({
        'specialite': specialite,
        'specialiteKey': specialiteKey,
        'ordrePreference': ordrePreference,
        'niveauInteret': niveauInteret,
        'commentaire':
            _newCommentaireInteretCtrl.text.trim() ?? 'no_comment'.tr,
      });
      _clearInteretForm();
    });
    _showSnackBar('specialty_added_success'.tr, const Color(0xFF2E7D32), 3);
  }

  void _clearInteretForm() {
    setState(() {
      _selectedSpecialiteForInteret = null;
      _newOrdrePreferenceCtrl.clear();
      _newNiveauInteretCtrl.clear();
      _newCommentaireInteretCtrl.clear();
    });
  }

  void _showEditInteretDialog(int index) {
    final interet = _interetsList[index];
    // final ordreCtrl =
    //     TextEditingController(text: interet['ordrePreference'].toString());
    final niveauCtrl =
        TextEditingController(text: interet['niveauInteret'].toString());
    final commentCtrl = TextEditingController(text: interet['commentaire']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('modify_specialty'
            .tr
            .replaceFirst('{specialty}', interet['specialite'])),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          // _buildSmallTextField(
          //     controller: ordreCtrl,
          //     label: 'order'.tr,
          //     hint: 'order_hint'.tr,
          //     icon: Icons.format_list_numbered),
          // const SizedBox(height: 12),
          _buildSmallTextField(
              controller: niveauCtrl,
              label: 'level'.tr,
              hint: 'level_hint'.tr,
              icon: Icons.star_outline),
          const SizedBox(height: 12),
          _buildSmallTextField(
              controller: commentCtrl,
              label: 'comment'.tr,
              hint: 'specify_interest'.tr,
              icon: Icons.comment_outlined,
              maxLines: 2),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('cancel'.tr)),
          ElevatedButton(
            onPressed: () {
              // final ordre = int.tryParse(ordreCtrl.text);
              final ordre = interet['ordrePreference'];
              final niveau = int.tryParse(niveauCtrl.text);
              if (ordre != null &&
                  ordre >= 1 &&
                  niveau != null &&
                  niveau >= 1 &&
                  niveau <= 10) {
                setState(() {
                  _interetsList[index]['ordrePreference'] = ordre;
                  _interetsList[index]['niveauInteret'] = niveau;
                  _interetsList[index]['commentaire'] = commentCtrl.text;
                  _interetsList.sort((a, b) =>
                      a['ordrePreference'].compareTo(b['ordrePreference']));
                  for (int i = 0; i < _interetsList.length; i++) {
                    _interetsList[i]['ordrePreference'] = i + 1;
                  }
                });
                Navigator.pop(context);
                _showSnackBar('modify_success'.tr, const Color(0xFF2E7D32), 3);
              } else {
                _showSnackBar('invalid_values'.tr, Colors.orange, 3);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E7D32)),
            child: Text('save'.tr, style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ─── Snack bar ────────────────────────────────────────────────────────────

  void _showSnackBar(String message, Color color, int dur) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(message),
          backgroundColor: color,
          duration: Duration(seconds: dur)),
    );
  }

  // ─── UI Helpers ───────────────────────────────────────────────────────────

  Widget _buildSmallTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.5)),
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        style: const TextStyle(fontSize: 13),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon, color: const Color(0xFF2E7D32), size: 16),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          labelStyle: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      decoration: const BoxDecoration(
        color: Color(0xFF2E7D32),
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20)),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child:
                  const Icon(Icons.arrow_back, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text('new_prospect'.tr,
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                  overflow: TextOverflow.ellipsis),
            ),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(12)),
              child:
                  const Icon(Icons.person_add, color: Colors.white, size: 22),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    bool required = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        style: const TextStyle(fontSize: 14),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon, color: const Color(0xFF2E7D32), size: 20),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          labelStyle: const TextStyle(color: Colors.grey),
        ),
        validator: required
            ? (value) =>
                value == null || value.isEmpty ? 'required_field'.tr : null
            : null,
      ),
    );
  }

  // ─── Champ avec sélecteur en bottom sheet ───────────────────────────────

  Widget _buildEntityPickerField({
    required String? value,
    required String label,
    required String hint,
    required IconData icon,
    required String entityType,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return GestureDetector(
      onTap: () => _showEntityPickerBottomSheet(
        entityType: entityType,
        currentValue: value,
        items: items,
        onSelect: onChanged,
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: InputDecorator(
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon, color: const Color(0xFF2E7D32), size: 20),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            labelStyle: const TextStyle(color: Colors.grey),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  value ?? hint,
                  style: TextStyle(
                      color: value != null ? Colors.black87 : Colors.grey,
                      fontSize: 14),
                ),
              ),
              const Icon(Icons.arrow_drop_down, color: Color(0xFF2E7D32)),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Dropdown simple ──────────────────────────────────────────────────────

  Widget _buildDropdownField({
    required String? value,
    required String label,
    required String hint,
    required IconData icon,
    required List<String> items,
    required Function(String?) onChanged,
    Function(String)? onAdd,
  }) {
    return GestureDetector(
      onTap: () {
        if (onAdd != null) {
          _showEntityPickerBottomSheet(
            entityType: 'source',
            currentValue: value,
            items: items,
            onSelect: onChanged,
            onAdd: onAdd,
          );
        } else {
          _showSimpleSearchableDialog(items, label, onChanged);
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF2E7D32).withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: InputDecorator(
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon, color: const Color(0xFF2E7D32), size: 20),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            labelStyle: const TextStyle(color: Colors.grey),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  value ?? hint,
                  style: TextStyle(
                      color: value != null ? Colors.black87 : Colors.grey,
                      fontSize: 14),
                ),
              ),
              const Icon(Icons.arrow_drop_down, color: Color(0xFF2E7D32)),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Bottom sheet de sélection simplifiée ─────────────────────────────

  void _showEntityPickerBottomSheet({
    required String entityType,
    required String? currentValue,
    required List<String> items,
    required Function(String?) onSelect,
    Function(String)? onAdd,
  }) {
    // Déterminer le titre et l'icône en fonction du type
    String title;
    IconData icon;
    Color iconColor = const Color(0xFF2E7D32);

    switch (entityType) {
      case 'etablissement':
        title = 'Établissement';
        icon = Icons.school_outlined;
        break;
      case 'classe':
        title = 'Classe';
        icon = Icons.class_outlined;
        break;
      case 'specialite':
        title = 'Filières';
        icon = Icons.school_outlined;
        break;
      case 'source':
        title = 'Sources';
        icon = Icons.sensors_rounded;
        break;
      default:
        title = entityType;
        icon = Icons.list;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        // ⚠️ CRUCIAL: Créer une liste de Map pour stocker la clé et sa traduction
        final List<Map<String, String>> itemMap = items.map((key) {
          return {
            'key': key,
            'translated': key.tr, // Traduction de la clé
          };
        }).toList();

        // Trier initialement par la traduction
        itemMap.sort((a, b) => a['translated']!.compareTo(b['translated']!));

        return StatefulBuilder(
          builder: (context, setBottomState) {
            // État local de la recherche
            String searchQuery = '';

            // Liste filtrée basée sur la recherche
            List<Map<String, String>> filteredItems = List.from(itemMap);

            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.6,
              maxChildSize: 0.9,
              minChildSize: 0.3,
              builder: (_, scrollController) {
                return Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Poignée
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      // Titre avec icône
                      Row(
                        children: [
                          Icon(icon, color: iconColor, size: 24),
                          const SizedBox(width: 12),
                          Text(
                            '${'select'.tr} $title',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Barre de recherche
                      TextField(
                        autofocus: false,
                        decoration: InputDecoration(
                          hintText: 'search'.tr,
                          prefixIcon: const Icon(Icons.search),
                          suffixIcon: searchQuery.isNotEmpty
                              ? IconButton(
                                  icon: Icon(Icons.clear,
                                      color: Colors.grey.shade400),
                                  onPressed: () {
                                    // Effacer la recherche
                                    setBottomState(() {
                                      searchQuery = '';
                                      filteredItems = List.from(itemMap);
                                    });
                                  },
                                )
                              : null,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                        onChanged: (query) {
                          setBottomState(() {
                            searchQuery = query.trim();

                            if (searchQuery.isEmpty) {
                              // Si la recherche est vide, afficher tous les items
                              filteredItems = List.from(itemMap);
                            } else {
                              // Filtrer les items dont la TRADUCTION contient la recherche
                              final lowerQuery = searchQuery.toLowerCase();

                              filteredItems = itemMap.where((item) {
                                final translated =
                                    item['translated']!.toLowerCase();
                                return translated.contains(lowerQuery);
                              }).toList();

                              // Trier par pertinence : ceux qui commencent par la recherche en premier
                              filteredItems.sort((a, b) {
                                final aTranslated =
                                    a['translated']!.toLowerCase();
                                final bTranslated =
                                    b['translated']!.toLowerCase();

                                final aStartsWith =
                                    aTranslated.startsWith(lowerQuery);
                                final bStartsWith =
                                    bTranslated.startsWith(lowerQuery);

                                if (aStartsWith && !bStartsWith) return -1;
                                if (!aStartsWith && bStartsWith) return 1;

                                return aTranslated.compareTo(bTranslated);
                              });
                            }
                          });
                        },
                      ),
                      const SizedBox(height: 12),

                      // Affichage du nombre de résultats
                      if (filteredItems.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            '${filteredItems.length} résultat${filteredItems.length > 1 ? 's' : ''}',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ),

                      // Liste des éléments
                      Expanded(
                        child: filteredItems.isEmpty
                            ? Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(32),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.search_off,
                                        size: 48,
                                        color: Colors.grey.shade400,
                                      ),
                                      const SizedBox(height: 16),
                                      Text(
                                        'no_result'.tr,
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : ListView.builder(
                                controller: scrollController,
                                itemCount: filteredItems.length,
                                itemBuilder: (_, index) {
                                  final item = filteredItems[index];
                                  final key = item['key']!;
                                  final translated = item['translated']!;
                                  final isSelected = key == currentValue;

                                  return ListTile(
                                    leading: Icon(
                                      isSelected
                                          ? Icons.radio_button_checked
                                          : Icons.radio_button_unchecked,
                                      color: isSelected
                                          ? const Color(0xFF2E7D32)
                                          : Colors.grey,
                                    ),
                                    title: Text(
                                      translated, // Afficher la traduction
                                      style: TextStyle(
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                        color: isSelected
                                            ? const Color(0xFF2E7D32)
                                            : Colors.black87,
                                      ),
                                    ),
                                    onTap: () {
                                      onSelect(key); // Passer la clé
                                      Navigator.pop(context);
                                    },
                                  );
                                },
                              ),
                      ),

                      // Bouton Ajouter
                      Padding(
                        padding: const EdgeInsets.only(top: 8, bottom: 16),
                        child: SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              _showAddEntityDialog(
                                entityType,
                                onAdded: (newItem) {
                                  onSelect(newItem);
                                  Navigator.pop(context);
                                },
                              );
                            },
                            icon: const Icon(Icons.add, size: 20),
                            label: Text(
                              'add'.tr + ' $title'.replaceFirst('s', ''),
                              style: const TextStyle(fontSize: 14),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF2E7D32),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  void _showAddEntityDialog(String entityType,
      {required Function(String) onAdded}) {
    final nameCtrl = TextEditingController();
    String? selectedType;
    final addressCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final cityCtrl = TextEditingController();
    final regionCtrl = TextEditingController();

    // Controllers pour Classe
    final classCtrl = TextEditingController();

    // Controllers pour Spécialité
    final specialityCtrl = TextEditingController();

    // Titre du dialogue
    String dialogTitle;
    switch (entityType) {
      case 'etablissement':
        dialogTitle = 'Ajouter un établissement';
        break;
      case 'classe':
        dialogTitle = 'Ajouter une classe';
        break;
      case 'specialite':
        dialogTitle = 'Ajouter une filière';
        break;
      case 'source':
        dialogTitle = 'Ajouter une source';
        break;
      default:
        dialogTitle = 'Ajouter';
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(dialogTitle),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (entityType == 'etablissement') ...[
                TextField(
                  controller: nameCtrl,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'Nom de l\'établissement *',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  hint: const Text('Type d\'établissement *'),
                  items: const [
                    DropdownMenuItem(
                        value: 'secondaire',
                        child: Text('Secondaire (Lycée/collège)')),
                    DropdownMenuItem(
                        value: 'superieur',
                        child: Text('superieur (Université)')),
                  ],
                  onChanged: (value) => selectedType = value,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                // const SizedBox(height: 12),
                // TextField(
                //   controller: addressCtrl,
                //   decoration: InputDecoration(
                //     hintText: 'Adresse',
                //     border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(12)),
                //   ),
                // ),
                // const SizedBox(height: 12),
                // TextField(
                //   controller: phoneCtrl,
                //   decoration: InputDecoration(
                //     hintText: 'Téléphone',
                //     border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(12)),
                //   ),
                //   keyboardType: TextInputType.phone,
                // ),
                // const SizedBox(height: 12),
                // TextField(
                //   controller: cityCtrl,
                //   decoration: InputDecoration(
                //     hintText: 'Ville',
                //     border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(12)),
                //   ),
                // ),
                // const SizedBox(height: 12),
                // TextField(
                //   controller: regionCtrl,
                //   decoration: InputDecoration(
                //     hintText: 'Région',
                //     border: OutlineInputBorder(
                //         borderRadius: BorderRadius.circular(12)),
                //   ),
                // ),
              ] else if (entityType == 'classe') ...[
                if (_selectedEtablissement == null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.red.shade200),
                    ),
                    child: Text(
                      'school_first'.tr,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                ] else ...[
                  TextField(
                    controller: classCtrl,
                    autofocus: true,
                    decoration: InputDecoration(
                      hintText: 'Nom de la classe *',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.school, size: 16, color: Colors.grey),
                        const SizedBox(width: 8),
                        Text(
                          'Établissement: $_selectedEtablissement',
                          style:
                              const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ],
              ] else if (entityType == 'specialite') ...[
                TextField(
                  controller: specialityCtrl,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'Nom de la filière *',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ] else if (entityType == 'source') ...[
                TextField(
                  controller: nameCtrl,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'Nom de la source *',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('cancel'.tr),
          ),
          ElevatedButton(
            onPressed: () async {
              final now = DateTime.now();
              String resultKey = 'error';
              String newItemName = '';

              if (entityType == 'etablissement') {
                final name = nameCtrl.text.trim();
                if (name.isEmpty || selectedType == null) {
                  _showSnackBar('Veuillez remplir tous les champs obligatoires',
                      Colors.orange, 3);
                  return;
                }

                final newEts = Etablissement(
                  idEtablissement: 'ets_${now.millisecondsSinceEpoch}',
                  nomEtablissement: name.trim(),
                  typeEtablissement: selectedType,
                  adresse: addressCtrl.text.trim().isEmpty
                      ? null
                      : addressCtrl.text.trim(),
                  telephone: phoneCtrl.text.trim().isEmpty
                      ? null
                      : phoneCtrl.text.trim(),
                  ville: cityCtrl.text.trim().isEmpty
                      ? null
                      : cityCtrl.text.trim(),
                  region: regionCtrl.text.trim().isEmpty
                      ? null
                      : regionCtrl.text.trim(),
                  createdAt: now,
                  syncState: SyncState.pending,
                );
                resultKey =
                    await LocalStorage.instance.saveEtablissement(newEts);
                newItemName = name;
                setState(() {
                  if (!_etablissementNames.contains(name)) {
                    _etablissementNames.add(name);
                  }
                  _allEtablissements.add(newEts);
                  _filteredEtablissementNames =
                      _getFilteredEtablissementNames();
                });
              } else if (entityType == 'classe') {
                final name = classCtrl.text.trim();
                if (name.isEmpty || _selectedEtablissement == null) {
                  _showSnackBar('Veuillez remplir tous les champs obligatoires',
                      Colors.orange, 3);
                  return;
                }

                // Générer une clé à partir du nom
                final key =
                    'class_${name.toLowerCase().replaceAll(' ', '_').replaceAll('é', 'e').replaceAll('è', 'e').replaceAll('ê', 'e').replaceAll('à', 'a').replaceAll('â', 'a').replaceAll('ô', 'o').replaceAll('û', 'u').replaceAll('ç', 'c').replaceAll("'", '_').replaceAll('-', '_').replaceAll(':', '').replaceAll('/', '_').replaceAll('(', '').replaceAll(')', '')}';

                Etablissement? existingEts = await LocalStorage.instance
                    .getEtablissementByNom(_selectedEtablissement!);
                String etsId;
                if (existingEts != null) {
                  etsId = existingEts.idEtablissement;
                } else {
                  final type = _selectedNiveauEtude == 'Baccalauréat'
                      ? 'secondaire'
                      : 'superieur';
                  final newEts = Etablissement(
                    idEtablissement: 'ets_${now.millisecondsSinceEpoch}',
                    nomEtablissement: _selectedEtablissement!,
                    typeEtablissement: type,
                    createdAt: now,
                    syncState: SyncState.pending,
                  );
                  await LocalStorage.instance.saveEtablissement(newEts);
                  etsId = newEts.idEtablissement;
                  setState(() {
                    if (!_etablissementNames
                        .contains(_selectedEtablissement!)) {
                      _etablissementNames.add(_selectedEtablissement!);
                    }
                    _allEtablissements.add(newEts);
                    _filteredEtablissementNames =
                        _getFilteredEtablissementNames();
                  });
                }

                final newClasse = Classe(
                  idClasse: 'classe_${now.millisecondsSinceEpoch}',
                  idEts: etsId,
                  libelleClasse: key,
                  createdAt: now,
                  syncState: SyncState.pending,
                );
                resultKey = await LocalStorage.instance.saveClasse(newClasse);
                newItemName = name;
                setState(() {
                  if (!_classKeys.contains(key)) {
                    _classKeys.add(key);
                  }
                  final translatedName = key.tr;
                  if (!_classes.contains(translatedName)) {
                    _classes.add(translatedName);
                  }
                });
              } else if (entityType == 'specialite') {
                final name = specialityCtrl.text.trim();
                if (name.isEmpty) {
                  _showSnackBar('Veuillez remplir tous les champs obligatoires',
                      Colors.orange, 3);
                  return;
                }

                final key = name
                    .toLowerCase()
                    .replaceAll(' ', '_')
                    .replaceAll('é', 'e')
                    .replaceAll('è', 'e')
                    .replaceAll('ê', 'e')
                    .replaceAll('à', 'a')
                    .replaceAll('â', 'a')
                    .replaceAll('ô', 'o')
                    .replaceAll('û', 'u')
                    .replaceAll('ç', 'c')
                    .replaceAll("'", '_')
                    .replaceAll('-', '_');

                final newSpec = Specialite(
                  idSpecialite: 'specialite_${now.millisecondsSinceEpoch}',
                  libelleSpecialite: key,
                  description: null,
                  createdAt: now,
                  syncState: SyncState.pending,
                );
                resultKey = await LocalStorage.instance.saveSpecialite(newSpec);
                newItemName = key.tr;
                setState(() {
                  if (!_specialityKeys.contains(key)) {
                    _specialityKeys.add(key);
                  }
                  final translatedName = key.tr;
                  if (!_specialites.contains(translatedName)) {
                    _specialites.add(translatedName);
                  }
                });
              } else if (entityType == 'source') {
                final name = nameCtrl.text.trim();
                if (name.isEmpty) {
                  _showSnackBar('Veuillez remplir tous les champs obligatoires',
                      Colors.orange, 3);
                  return;
                }
                newItemName = name;
                setState(() {
                  if (!_sources.contains(name)) _sources.add(name);
                });
                resultKey = 'success';
              }

              if (resultKey.contains('success')) {
                _showSnackBar(
                  resultKey.tr,
                  const Color(0xFF2E7D32),
                  3,
                );
                Navigator.pop(context);
                onAdded(newItemName);
              } else {
                _showSnackBar(resultKey.tr, Colors.orange, 3);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2E7D32),
              foregroundColor: Colors.white,
            ),
            child: Text('add'.tr),
          ),
        ],
      ),
    );
  }

  // ─── Dialogue de sélection simple ────────────────────────────────────────

  void _showSimpleSearchableDialog(
      List<String> items, String title, Function(String?) onChanged) {
    final searchCtrl = TextEditingController();
    List<String> filtered = List.from(items);

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, ss) => Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9,
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.8),
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${'select'.tr} $title',
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
                TextField(
                  controller: searchCtrl,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'search'.tr,
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: searchCtrl.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              searchCtrl.clear();
                              ss(() => filtered = List.from(items));
                            })
                        : null,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onChanged: (v) => ss(() {
                    filtered = v.isEmpty
                        ? List.from(items)
                        : items
                            .where((i) =>
                                i.toLowerCase().contains(v.toLowerCase()))
                            .toList();
                  }),
                ),
                const SizedBox(height: 12),
                Flexible(
                  child: filtered.isEmpty
                      ? Center(
                          child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Text('no_result'.tr),
                        ))
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: filtered.length,
                          itemBuilder: (_, i) => ListTile(
                            leading: const Icon(Icons.check_circle_outline,
                                color: Color(0xFF2E7D32)),
                            title: Text(filtered[i]),
                            onTap: () {
                              onChanged(filtered[i]);
                              Navigator.pop(context);
                            },
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Date / heure ────────────────────────────────────────────────────────

  Widget _buildDateTimeField({
    required TextEditingController controller,
    required String label,
    required String hint,
  }) {
    const Color green = Color(0xFF2E7D32);

    Future<void> pick(BuildContext ctx) async {
      final date = await showDatePicker(
        context: ctx,
        initialDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime(2100),
        builder: (c, child) => Theme(
          data: Theme.of(c)
              .copyWith(colorScheme: const ColorScheme.light(primary: green)),
          child: child!,
        ),
      );
      if (date == null || !mounted) return;
      final time = await showTimePicker(
        context: ctx,
        initialTime: TimeOfDay.now(),
        builder: (c, child) => Theme(
          data: Theme.of(c)
              .copyWith(colorScheme: const ColorScheme.light(primary: green)),
          child: child!,
        ),
      );
      if (time == null) return;
      _date_relance =
          DateTime(date.year, date.month, date.day, time.hour, time.minute);
      controller.text = '${_date_relance?.day.toString().padLeft(2, '0')}/'
          '${_date_relance?.month.toString().padLeft(2, '0')}/'
          '${_date_relance?.year} '
          '${time.hour.toString().padLeft(2, '0')}:'
          '${time.minute.toString().padLeft(2, '0')}';
    }

    return GestureDetector(
      onTap: () => pick(context),
      child: AbsorbPointer(
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: green.withOpacity(0.5)),
          ),
          child: TextFormField(
            controller: controller,
            style: const TextStyle(fontSize: 13),
            decoration: InputDecoration(
              labelText: label,
              hintText: hint,
              prefixIcon:
                  const Icon(Icons.calendar_today, color: green, size: 16),
              suffixIcon: const Icon(Icons.access_time, color: green, size: 16),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              labelStyle: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ),
        ),
      ),
    );
  }

  // ─── SAVE PROSPECT ────────────────────────────────────────────────────────

  Future<void> _saveProspect() async {
    LoadingService().show(context, message: 'saving_prospect'.tr);

    if (!_formKey.currentState!.validate()) {
      LoadingService().hide();
      return;
    }

    if (_interetsList.isEmpty) {
      _showSnackBar('add_specialty_warning'.tr, Colors.orange, 5);
      _toggleSection('interet');
      LoadingService().hide();
      return;
    }

    if (_selectedEtablissement == null || _selectedEtablissement!.isEmpty) {
      _showSnackBar('select_establishment_first'.tr, Colors.orange, 5);
      _toggleSection('academiques');
      LoadingService().hide();
      return;
    }

    final Source? src = await LocalStorage.instance.getLastRecSource();
    final Fiche? f = await LocalStorage.instance.getLastRecFiche();

    if (src == null || f == null) {
      _showSnackBar('missing_source_or_fiche'.tr, Colors.red, 5);
      LoadingService().hide();
      return;
    }

    final now = DateTime.now();

    // ── ETABLISSEMENT ──
    Etablissement? existingEts = await LocalStorage.instance
        .getEtablissementByNom(_selectedEtablissement!);

    Etablissement ets;

    if (existingEts != null) {
      ets = existingEts;
    } else {
      final isBac = _selectedNiveauEtude == 'Baccalauréat';
      final type = isBac ? 'secondaire' : 'superieur';

      ets = Etablissement(
        idEtablissement: 'ets_${now.millisecondsSinceEpoch.toString()}',
        nomEtablissement: _selectedEtablissement!.trim(),
        typeEtablissement: type,
        createdAt: now,
        syncState: SyncState.pending,
      );

      final r = await LocalStorage.instance.saveEtablissement(ets);

      if (!r.contains('success')) {
        _showSnackBar(r.tr, Colors.orange, 3);
        LoadingService().hide();
        return;
      }
    }

    // ── CLASSE ──
    Classe? classe;

    if (_shouldShowClassField() &&
        _selectedClasse != null &&
        _selectedClasse!.isNotEmpty) {
      final classKeyToUse = _selectedClasse!;

      Classe? existingClasse =
          await LocalStorage.instance.getClasseByLibelleAndEts(
        classKeyToUse,
        ets.idEtablissement,
      );

      if (existingClasse != null) {
        classe = existingClasse;
      } else {
        final newClasse = Classe(
          idClasse: 'cls_${now.millisecondsSinceEpoch.toString()}',
          idEts: ets.idEtablissement,
          libelleClasse: classKeyToUse.trim(),
          createdAt: now,
          syncState: SyncState.pending,
        );
        newClasse.ets.value = ets;
        final r = await LocalStorage.instance.saveClasse(newClasse);
        // we then save the ets in the saveClasse method (Ctrl + click on saveClasse to see more)
        if (!r.contains('success')) {
          _showSnackBar(r.tr, Colors.orange, 3);
          LoadingService().hide();
          return;
        }

        classe = newClasse;
      }
    }

    // ── PROSPECT ──
    final prospect = Prospect(
      idProspect: 'prospect_${now.millisecondsSinceEpoch}',
      idfiche: f.idFiche,
      idClass: classe?.idClasse ?? '',
      nomComplet: _nomCompletCtrl.text.trim(),
      telephone: _telephoneCtrl.text,
      nomParent: _nomParentCtrl.text.trim(),
      telephoneParent: _telephoneParentCtrl.text,
      email: _emailCtrl.text.isEmpty ? null : _emailCtrl.text.trim(),
      niveauEtude: _selectedNiveauEtude.trim(),
      adresse: _adresseCtrl.text.isEmpty ? null : _adresseCtrl.text.trim(),
      sexe: _selectedSexe,
      typeProspect: _selectedTypeProspect,
      commentaireGen: _commentaireCtrl.text.trim(),
      date_relance: _date_relance,
      createdAt: now,
      source_infos: _selectedSource.trim(),
      syncState: SyncState.pending,
    );
    // 🔥 FIX 1: LINK CLASSE (IMPORTANT)
    prospect.classe.value = classe;
    // 🔥 FIX 2: LINK FICHE (RECOMMENDED)
    prospect.fiche.value = f;
    prospect.idClass = classe?.idClasse ?? '';
    final prospectResult = await LocalStorage.instance.saveProspect(prospect);

    // await prospect.classe.save();
    // await prospect.fiche.save();

    if (!prospectResult.contains('success')) {
      _showSnackBar(prospectResult.tr, Colors.orange, 5);
      LoadingService().hide();
      return;
    }
    // await LocalStorage.instance.isar.writeTxn(() async {});

    // await LocalStorage.instance.isar.writeTxn(() async {});

    // ── INTERETS ──
    int savedInterets = 0;

    for (var item in _interetsList) {
      final specialiteKey = item['specialiteKey'] ?? item['specialite'];

      Specialite? specialite =
          await LocalStorage.instance.getSpecialiteByNom(specialiteKey);

      if (specialite == null) {
        specialite = Specialite(
            idSpecialite:
                'specialite_${now.millisecondsSinceEpoch}_$savedInterets',
            libelleSpecialite: specialiteKey.trim(),
            description: null,
            createdAt: now,
            syncState: SyncState.pending);

        final r = await LocalStorage.instance.saveSpecialite(specialite);

        if (!r.contains('success')) {
          _showSnackBar(r.tr, Colors.orange, 3);
          continue;
        }
      }

      final interet = InteretFiliere(
        idInteret:
            'interet_${now.millisecondsSinceEpoch}_${item['ordrePreference']}',
        idProspect: prospect.idProspect,
        idSpecialite: specialite.idSpecialite,
        ordrePreference: item['ordrePreference'] ?? 0,
        niveauInteret: item['niveauInteret'] ?? 0,
        commentaire: item['commentaire'] ?? '',
        createdAt: now,
        syncState: SyncState.pending,
      );

      interet.prospect.value = prospect;
      interet.specialite.value = specialite;

      await LocalStorage.instance.saveInteret(interet);

      prospect.interets.add(interet);

      savedInterets++;
    }

    await LocalStorage.instance.isar.writeTxn(() async {
      await prospect.interets.save();
    });

    _showSnackBar(
      'prospect_saved'.tr.replaceFirst('{count}', '$savedInterets'),
      const Color(0xFF2E7D32),
      3,
    );

    _resetForm();
    LoadingService().hide();
  }

  // ─── Reset ────────────────────────────────────────────────────────────────

  void _resetForm() {
    _nomCompletCtrl.clear();
    _telephoneCtrl.clear();
    _emailCtrl.clear();
    _adresseCtrl.clear();
    _commentaireCtrl.clear();
    _concerneCtrl.clear();
    setState(() {
      _selectedSexe = '';
      _selectedTypeProspect = '';
      _selectedEtablissement = null;
      _selectedClasse = null;
      _selectedSource = '';
      _selectedNiveauEtude = '';
      _scoreInteret = 5;
      _interetsList.clear();
      _filteredEtablissementNames = _getFilteredEtablissementNames();
    });
    _navigateBack();
  }

  // ─── Navigation ──────────────────────────────────────────────────────────

  void _navigateBack() => Navigator.pop(context);

  // ─── Export helpers ──────────────────────────────────────────────────────

  Future<void> _showExportOptions(Fiche fiche) async {
    await Future.delayed(const Duration(milliseconds: 500));
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      backgroundColor: Colors.white,
      builder: (context) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 12),
          Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          Text('fiche_saved_success'.tr,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2E7D32))),
          const SizedBox(height: 8),
          Text('export_fiche_question'.tr,
              style: const TextStyle(fontSize: 14, color: Colors.grey)),
          const Divider(height: 24),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12)),
                child: Icon(Icons.picture_as_pdf,
                    color: Colors.red.shade700, size: 24)),
            title: Text('preview_pdf'.tr),
            subtitle: Text('preview_before_export'.tr),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () async {
              Navigator.pop(context);
              await ExportService.previewFichePDF(fiche);
            },
          ),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12)),
                child: Icon(Icons.picture_as_pdf,
                    color: Colors.red.shade700, size: 24)),
            title: Text('export_pdf'.tr),
            subtitle: Text('download_or_share'.tr),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () async {
              Navigator.pop(context);
              await _exportAndSharePDF(fiche);
            },
          ),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: const Color(0xFF2E7D32).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.table_chart,
                    color: Color(0xFF2E7D32), size: 24)),
            title: Text('preview_excel'.tr),
            subtitle: Text('preview_before_export'.tr),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () async {
              Navigator.pop(context);
              await ExportService.previewFicheExcel(fiche);
            },
          ),
          ListTile(
            leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: const Color(0xFF2E7D32).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.table_chart,
                    color: Color(0xFF2E7D32), size: 24)),
            title: Text('export_excel'.tr),
            subtitle: Text('download_or_share'.tr),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () async {
              Navigator.pop(context);
              await _exportAndShareExcel(fiche);
            },
          ),
          const SizedBox(height: 8),
          TextButton(
              onPressed: _navigateBack,
              child: Text('later'.tr, style: const TextStyle(fontSize: 14))),
          const SizedBox(height: 12),
        ]),
      ),
    );
  }

  Future<void> _exportAndSharePDF(Fiche fiche) async {
    _showLoadingDialog('generating_pdf'.tr);
    final file = await ExportService.exportFicheToPDF(fiche);
    if (mounted) Navigator.pop(context);
    if (file != null && mounted) {
      await ExportService.shareFile(file, file.path.split('/').last);
      _showSnackBar('pdf_export_success'.tr, const Color(0xFF2E7D32), 5);
      _navigateBack();
    } else {
      _showSnackBar('pdf_export_error'.tr, Colors.red, 5);
    }
  }

  Future<void> _exportAndShareExcel(Fiche fiche) async {
    _showLoadingDialog('generating_excel'.tr);
    final file = await ExportService.exportFicheToExcel(fiche);
    if (mounted) Navigator.pop(context);
    if (file != null && mounted) {
      await ExportService.shareFile(file, file.path.split('/').last);
      _showSnackBar('excel_export_success'.tr, const Color(0xFF2E7D32), 3);
      _navigateBack();
    } else {
      _showSnackBar('excel_export_error'.tr, Colors.red, 5);
    }
  }

  void _showLoadingDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(message),
        ]),
      ),
    );
  }
}
