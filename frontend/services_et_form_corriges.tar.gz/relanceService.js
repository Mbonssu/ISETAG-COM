import { api } from './api';
// Route réelle (doc YAML) : /prospect_api/ISETAG_COM.relances/
// Schéma Relance : idRelance, idProspect, dateRelance, sujet, description
const BASE_URL = '/prospect_api/ISETAG_COM.relances/';
export const relanceService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idRelance: `REL-${Date.now()}`, idProspect: data.idProspect, dateRelance: data.dateRelance, sujet: data.sujet, description: data.description }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idRelance: id, idProspect: data.idProspect, dateRelance: data.dateRelance, sujet: data.sujet, description: data.description }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
