import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.zones/
// Schéma Zone requis : idZone, libele, description, quartier, ville, pays, region, lieuDepart, lieuArrivee
const BASE_URL = '/campagne_api/ISETAG_COM.zones/';
export const zoneService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idZone: `ZONE-${Date.now()}`, libele: data.libele ?? data.quartier, description: data.description, quartier: data.quartier, ville: data.ville, pays: data.pays ?? 'Cameroun', region: data.region, lieuDepart: data.lieuDepart, lieuArrivee: data.lieuArrivee ?? data.lieuFin }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idZone: id, libele: data.libele ?? data.quartier, description: data.description, quartier: data.quartier, ville: data.ville, pays: data.pays ?? 'Cameroun', region: data.region, lieuDepart: data.lieuDepart, lieuArrivee: data.lieuArrivee ?? data.lieuFin }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
