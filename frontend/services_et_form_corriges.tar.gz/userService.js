import { api } from './api';
// Route réelle (doc YAML) : /user_api/ISETAG_COM.users/
const BASE_URL = '/user_api/ISETAG_COM.users/';
export const userService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, data),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, data),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
