import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.etablissements/
// Schéma requis : idEtablissement, nom, adresse, ville, region, type, telephone
const BASE_URL = '/campagne_api/ISETAG_COM.etablissements/';
export const etablissementService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idEtablissement: `ETAB-${Date.now()}`, nom: data.nom ?? data.name, adresse: data.adresse, ville: data.ville, region: data.region, type: data.type ?? data.typeEtablissement, telephone: data.telephone }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idEtablissement: id, nom: data.nom ?? data.name, adresse: data.adresse, ville: data.ville, region: data.region, type: data.type ?? data.typeEtablissement, telephone: data.telephone }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
