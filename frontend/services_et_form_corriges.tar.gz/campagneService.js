import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.campagnes/
// Schéma requis : idCampagne, libele, description, dateDebut, dateFin, objectif, type
const BASE_URL = '/campagne_api/ISETAG_COM.campagnes/';
export const campagneService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idCampagne: `CAMP-${Date.now()}`, libele: data.libele, description: data.description, dateDebut: data.dateDebut, dateFin: data.dateFin, objectif: data.objectif, type: data.type }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idCampagne: id, libele: data.libele, description: data.description, dateDebut: data.dateDebut, dateFin: data.dateFin, objectif: data.objectif, type: data.type }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
