import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.sources/
const BASE_URL = '/campagne_api/ISETAG_COM.sources/';
export const sourceService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idSource: `SRC-${Date.now()}`, ...data }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idSource: id, ...data }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
