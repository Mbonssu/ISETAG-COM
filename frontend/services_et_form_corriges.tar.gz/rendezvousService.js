import { api } from './api';
// Route réelle (doc YAML) : /prospect_api/ISETAG_COM.rendezvous/
const BASE_URL = '/prospect_api/ISETAG_COM.rendezvous/';
export const rendezvousService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idRdv: `RDV-${Date.now()}`, ...data }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idRdv: id, ...data }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
