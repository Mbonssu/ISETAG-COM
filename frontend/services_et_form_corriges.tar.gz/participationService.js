import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.participations/
// Schéma requis : idParticipation, idUtilisateur, idSortie, dateAssignation, heureArrivee, heureDepart, statut, observation
const BASE_URL = '/campagne_api/ISETAG_COM.participations/';
export const participationService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idParticipation: `PART-${Date.now()}`, idUtilisateur: data.idUtilisateur, idSortie: data.idSortie, dateAssignation: data.dateAssignation, heureArrivee: data.heureArrivee, heureDepart: data.heureDepart, statut: data.statut, observation: data.observation }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idParticipation: id, idUtilisateur: data.idUtilisateur, idSortie: data.idSortie, dateAssignation: data.dateAssignation, heureArrivee: data.heureArrivee, heureDepart: data.heureDepart, statut: data.statut, observation: data.observation }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
