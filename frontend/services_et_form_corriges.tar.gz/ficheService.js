import { api } from './api';
// Route réelle (doc YAML) : /campagne_api/ISETAG_COM.fiches-sortie/
// Schéma requis : idFiche, idParticipation, idProspect, idSource, dateCollecte, commentaire, scoreInteret
const BASE_URL = '/campagne_api/ISETAG_COM.fiches-sortie/';
export const ficheService = {
  getAll: (params = {}) => {
    const qs = new URLSearchParams(Object.fromEntries(Object.entries(params).filter(([,v]) => v != null && v !== ''))).toString();
    return api.get(qs ? `${BASE_URL}?${qs}` : BASE_URL);
  },
  getById: (id) => api.get(`${BASE_URL}${id}/`),
  create: (data) => api.post(BASE_URL, { idFiche: `FICH-${Date.now()}`, idParticipation: data.idParticipation, idProspect: data.idProspect, idSource: data.idSource, dateCollecte: data.dateCollecte, commentaire: data.commentaire, scoreInteret: data.scoreInteret ?? 0 }),
  update: (id, data) => api.put(`${BASE_URL}${id}/`, { idFiche: id, idParticipation: data.idParticipation, idProspect: data.idProspect, idSource: data.idSource, dateCollecte: data.dateCollecte, commentaire: data.commentaire, scoreInteret: data.scoreInteret }),
  delete: (id) => api.delete(`${BASE_URL}${id}/`),
};
