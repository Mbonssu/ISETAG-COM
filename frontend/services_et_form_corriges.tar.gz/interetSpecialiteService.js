/**
 * Service de gestion des intérêts spécialité.
 * Basé sur la documentation officielle ISETAG_COM_API.yaml
 *
 * Routes réelles :
 *   GET    /specialite_api/ISETAG_COM.interetspecialites/                          → liste tous les intérêts
 *   POST   /specialite_api/ISETAG_COM.interetspecialites/                          → créer un intérêt
 *   PUT    /specialite_api/ISETAG_COM.interetspecialites/{id}/                     → mettre à jour
 *   DELETE /specialite_api/ISETAG_COM.interetspecialites/{id}/                     → supprimer
 *   GET    /specialite_api/ISETAG_COM.interetspecialites/prospect/{prospect_id}/   → intérêts D'UN PROSPECT
 *
 * Schéma interetSpecialiteRequest (tous requis) :
 *   idInteret    : string
 *   idSpecialite : string
 *   idProspect   : string
 *   niveauInteret: string (max 50)
 */

import { api } from './api';

const BASE_URL       = '/specialite_api/ISETAG_COM.interetspecialites/';
const PROSPECT_URL   = (prospectId) => `${BASE_URL}prospect/${prospectId}/`;

export const interetSpecialiteService = {

  /**
   * GET /specialite_api/ISETAG_COM.interetspecialites/prospect/{prospect_id}/
   * Récupère UNIQUEMENT les intérêts du prospect ciblé.
   * C'est ce qui manquait et causait le bug "ça affecte tous les prospects".
   */
  getByProspect: (idProspect) => {
    console.log('📡 GET interets for prospect:', idProspect);
    return api.get(PROSPECT_URL(idProspect));
  },

  /**
   * GET /specialite_api/ISETAG_COM.interetspecialites/{id}/
   * Récupère un intérêt précis par son ID.
   */
  getById: (idInteret) => {
    return api.get(`${BASE_URL}${idInteret}/`);
  },

  /**
   * POST /specialite_api/ISETAG_COM.interetspecialites/
   * Crée un intérêt pour un prospect.
   *
   * @param {{ idSpecialite, idProspect, niveauInteret }} data
   */
  create: (data) => {
    const payload = {
      idInteret:     `INT-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
      idSpecialite:  data.idSpecialite,
      idProspect:    data.idProspect,
      niveauInteret: data.niveauInteret,
    };
    console.log('📝 CREATE interet:', payload);
    return api.post(BASE_URL, payload);
  },

  /**
   * PUT /specialite_api/ISETAG_COM.interetspecialites/{id}/
   * Met à jour le niveauInteret d'un intérêt existant.
   *
   * @param {string} idInteret
   * @param {{ idSpecialite, idProspect, niveauInteret }} data
   */
  update: (idInteret, data) => {
    const payload = {
      idInteret:     idInteret,
      idSpecialite:  data.idSpecialite,
      idProspect:    data.idProspect,
      niveauInteret: data.niveauInteret,
    };
    console.log('📝 UPDATE interet:', idInteret, payload);
    return api.put(`${BASE_URL}${idInteret}/`, payload);
  },

  /**
   * DELETE /specialite_api/ISETAG_COM.interetspecialites/{id}/
   * Supprime un intérêt spécifique.
   */
  delete: (idInteret) => {
    console.log('🗑️ DELETE interet:', idInteret);
    return api.delete(`${BASE_URL}${idInteret}/`);
  },

  /**
   * Remplace TOUS les intérêts d'un prospect par une nouvelle liste.
   * C'est la méthode principale à appeler lors de la modification d'un prospect.
   *
   * Algorithme :
   *   1. Récupère les intérêts existants du prospect
   *   2. DELETE ceux qui ont été retirés
   *   3. PUT ceux dont le niveauInteret a changé
   *   4. POST les nouveaux
   *
   * @param {string} idProspect
   * @param {Array<{ idFiliere, niveauInteret, idInteret? }>} newList
   */
  syncInterets: async (idProspect, newList) => {
    console.log('🔄 SYNC interets for prospect:', idProspect, newList);

    // 1. Charger les intérêts actuels de CE prospect
    let existing = [];
    try {
      const res = await interetSpecialiteService.getByProspect(idProspect);
      existing  = Array.isArray(res) ? res : (res?.results ?? []);
    } catch {
      existing = [];
    }

    // 2. Calculer les diff
    const toDelete = existing.filter(
      ex => !newList.some(n => n.idFiliere === ex.idSpecialite)
    );
    const toAdd = newList.filter(
      n => !existing.some(ex => ex.idSpecialite === n.idFiliere)
    );
    const toUpdate = newList.filter(n => {
      const match = existing.find(ex => ex.idSpecialite === n.idFiliere);
      return match && match.niveauInteret !== n.niveauInteret;
    });

    // 3. Appliquer en parallèle
    await Promise.allSettled([
      ...toDelete.map(ex =>
        interetSpecialiteService.delete(ex.idInteret)
      ),
      ...toUpdate.map(n => {
        const ex = existing.find(e => e.idSpecialite === n.idFiliere);
        return interetSpecialiteService.update(ex.idInteret, {
          idSpecialite:  n.idFiliere,
          idProspect:    idProspect,
          niveauInteret: n.niveauInteret,
        });
      }),
      ...toAdd.map(n =>
        interetSpecialiteService.create({
          idSpecialite:  n.idFiliere,
          idProspect:    idProspect,
          niveauInteret: n.niveauInteret,
        })
      ),
    ]);

    console.log(`✅ Sync done — deleted: ${toDelete.length}, updated: ${toUpdate.length}, added: ${toAdd.length}`);
  },
};
