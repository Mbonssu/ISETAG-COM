/**
 * Service de gestion des prospects.
 * Basé sur la documentation officielle ISETAG_COM_API.yaml
 *
 * Routes réelles :
 *   GET    /prospect_api/ISETAG_COM.prospects/       → liste
 *   POST   /prospect_api/ISETAG_COM.prospects/       → créer
 *   PUT    /prospect_api/ISETAG_COM.prospects/       → mettre à jour (sans id dans l'URL !)
 *   DELETE /prospect_api/ISETAG_COM.prospects/       → supprimer
 *   GET    /prospect_api/ISETAG_COM.prospects/{id}/  → récupérer un prospect
 *   PUT    /prospect_api/ISETAG_COM.prospects/{id}/  → mettre à jour par id
 *   DELETE /prospect_api/ISETAG_COM.prospects/{id}/  → supprimer par id
 *
 * ⚠️  Note : specialiteInteret est readOnly dans la réponse.
 *     Les intérêts sont gérés séparément via interetSpecialiteService.
 *
 * Schéma ProspectRequest (requis : idProspect, nomComplet) :
 *   idProspect, nomComplet, email, telephone, adresse, ville,
 *   codePostal, pays, sexe, dateNaissance, niveauEtude, domaineEtude,
 *   typeProspect, nomParent, numeroParent
 */

import { api } from './api';

const BASE_URL = '/prospect_api/ISETAG_COM.prospects/';

export const prospectService = {

  getAll: (params = {}) => {
    const cleanParams = {};
    Object.keys(params).forEach(key => {
      if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
        cleanParams[key] = params[key];
      }
    });
    const queryString = new URLSearchParams(cleanParams).toString();
    console.log('📡 GET all prospects');
    return api.get(queryString ? `${BASE_URL}?${queryString}` : BASE_URL);
  },

  getById: (idProspect) => {
    console.log('📡 GET prospect:', idProspect);
    return api.get(`${BASE_URL}${idProspect}/`);
  },

  /**
   * POST /prospect_api/ISETAG_COM.prospects/
   * Champs requis : idProspect, nomComplet
   * NE PAS inclure specialiteInteret — géré via interetSpecialiteService
   */
  create: (data) => {
    const payload = {
      idProspect:   `PROS-${Date.now()}`,
      nomComplet:   data.nomComplet,
      email:        data.email        || null,
      telephone:    data.telephone    || null,
      adresse:      data.adresse      || null,
      ville:        data.ville        || null,
      codePostal:   data.codePostal   || null,
      pays:         data.pays         || null,
      sexe:         data.sexe         || null,
      dateNaissance:data.dateNaissance|| null,
      niveauEtude:  data.niveauEtude  || null,
      domaineEtude: data.domaineEtude || null,
      typeProspect: data.typeProspect || null,
      nomParent:    data.nomParent    || null,
      numeroParent: data.numeroParent || null,
    };
    console.log('📝 CREATE prospect:', payload);
    return api.post(BASE_URL, payload);
  },

  /**
   * PUT /prospect_api/ISETAG_COM.prospects/{id}/
   * NE PAS inclure specialiteInteret — géré via interetSpecialiteService
   */
  update: (idProspect, data) => {
    const payload = {
      idProspect:   idProspect,
      nomComplet:   data.nomComplet,
      email:        data.email        || null,
      telephone:    data.telephone    || null,
      adresse:      data.adresse      || null,
      ville:        data.ville        || null,
      codePostal:   data.codePostal   || null,
      pays:         data.pays         || null,
      sexe:         data.sexe         || null,
      dateNaissance:data.dateNaissance|| null,
      niveauEtude:  data.niveauEtude  || null,
      domaineEtude: data.domaineEtude || null,
      typeProspect: data.typeProspect || null,
      nomParent:    data.nomParent    || null,
      numeroParent: data.numeroParent || null,
    };
    console.log('📝 UPDATE prospect:', idProspect);
    return api.put(`${BASE_URL}${idProspect}/`, payload);
  },

  delete: (idProspect) => {
    console.log('🗑️ DELETE prospect:', idProspect);
    return api.delete(`${BASE_URL}${idProspect}/`);
  },
};
